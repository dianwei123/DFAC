# 本项目未开启 minify（isMinifyEnabled=false），保留基础混淆规则以便后续启用。
-keepattributes *Annotation*
-keep class com.memorychat.domain.model.** { *; }

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
