package com.memorychat.di

import android.content.Context
import androidx.work.WorkManager
import com.memorychat.data.local.AppDatabase
import com.memorychat.data.repo.ChatRepository
import com.memorychat.data.settings.SettingsRepository
import com.memorychat.domain.HeuristicTokenEstimator
import com.memorychat.domain.LocalToolRuntime
import com.memorychat.domain.ToolCatalog
import com.memorychat.network.ChatCompletionClient
import com.memorychat.network.DeepSeekHttpClient
import com.memorychat.network.MockChatCompletionClient
import com.memorychat.network.SwitchingChatCompletionClient
import com.memorychat.work.SummaryScheduler

/**
 * 极简依赖容器。项目规模不大，用 ServiceLocator 足够；
 * 如果后续要接 Hilt，替换这一处即可，其余代码只依赖构造参数。
 */
object ServiceLocator {

    @Volatile
    private var initialized = false

    lateinit var database: AppDatabase
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var chatClient: ChatCompletionClient
        private set

    lateinit var repository: ChatRepository
        private set

    lateinit var summaryScheduler: SummaryScheduler
        private set

    val isInitialized: Boolean get() = initialized

    fun init(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            val appContext = context.applicationContext
            database = AppDatabase.get(appContext)
            settingsRepository = SettingsRepository(appContext)
            chatClient = SwitchingChatCompletionClient(
                settingsProvider = { settingsRepository.snapshot() },
                remote = DeepSeekHttpClient(settingsProvider = { settingsRepository.snapshot() }),
                mock = MockChatCompletionClient(),
            )
            // WorkManager 用惰性提供者，应用启动阶段不触碰它（也方便 Robolectric 测试注入）。
            summaryScheduler = SummaryScheduler { WorkManager.getInstance(appContext) }
            repository = ChatRepository(
                messageDao = database.messageDao(),
                sessionDao = database.sessionDao(),
                summaryCacheDao = database.summaryCacheDao(),
                settingsRepository = settingsRepository,
                tokenEstimator = HeuristicTokenEstimator(),
                chatClient = chatClient,
                summaryScheduler = summaryScheduler,
                toolRuntimeProvider = { sessionId ->
                    LocalToolRuntime(
                        searchHistory = { query ->
                            database.messageDao()
                                .search(sessionId, query, 5)
                                .map { message ->
                                    val speaker = if (message.role == "user") "用户" else "助手"
                                    "$speaker：${message.content}"
                                }
                        },
                        capabilityProvider = {
                            val settings = settingsRepository.snapshot()
                            """
                            {"app":"DFAC","features":["历史压缩","SSE 流式","prompt cache 体检","本地工具"],
                             "token_threshold":${settings.tokenThreshold},
                             "recent_rounds":${settings.recentRounds},
                             "tools_enabled":${settings.toolsEnabled},
                             "mode":"${if (settings.isMockMode) "mock" else "online"}"}
                            """.trimIndent()
                        },
                    )
                },
            )
            initialized = true
        }
    }

    /** 供单元测试/工具判断：当前是否配置了工具清单。 */
    fun toolCatalogSize(): Int = ToolCatalog.ALL.size
}
