package com.memorychat.ui.chat

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.memorychat.R
import com.memorychat.databinding.ItemSessionBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 侧边栏「历史对话」适配器：点按切换，长按删除。 */
class SessionAdapter(
    private val onSwitch: (Long) -> Unit,
    private val onDelete: (Long) -> Unit,
) : ListAdapter<SessionUi, SessionAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(ItemSessionBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemSessionBinding,
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: SessionUi) {
            val context = binding.root.context
            binding.textSessionTitle.text = item.title.ifBlank { "未命名对话" }
            binding.textSessionTitle.setTextColor(
                ContextCompat.getColor(
                    context,
                    if (item.isCurrent) R.color.brand_primary else R.color.on_surface,
                ),
            )
            binding.textSessionMeta.text = buildString {
                append(formatTime(item.updatedAt))
                if (item.compressedRounds > 0) append(" · 压缩 ${item.compressedRounds} 轮")
                if (item.savedTokens > 0) append(" · 省 ${item.savedTokens} tok")
                if (item.isCurrent) append(" · 当前")
            }
            binding.root.setOnClickListener { onSwitch(item.id) }
            binding.root.setOnLongClickListener {
                onDelete(item.id)
                true
            }
        }
    }

    companion object {
        private val timeFormat = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA)

        private fun formatTime(millis: Long): String =
            if (millis <= 0L) "—" else timeFormat.format(Date(millis))

        private val DIFF = object : DiffUtil.ItemCallback<SessionUi>() {
            override fun areItemsTheSame(oldItem: SessionUi, newItem: SessionUi): Boolean =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: SessionUi, newItem: SessionUi): Boolean =
                oldItem == newItem
        }
    }
}
