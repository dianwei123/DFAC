package com.memorychat.ui.chat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.memorychat.R
import com.memorychat.data.local.MessageStatus
import com.memorychat.databinding.ItemMessageAssistantBinding
import com.memorychat.databinding.ItemMessageUserBinding

/** 消息列表适配器：用户气泡靠右、助手气泡靠左，流式时带光标，失败时可点重发。 */
class MessageAdapter(
    private val onRetryClick: () -> Unit,
) : ListAdapter<UiMessage, RecyclerView.ViewHolder>(DIFF) {

    override fun getItemViewType(position: Int): Int =
        if (getItem(position).isUser) TYPE_USER else TYPE_ASSISTANT

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_USER) {
            UserViewHolder(ItemMessageUserBinding.inflate(inflater, parent, false))
        } else {
            AssistantViewHolder(ItemMessageAssistantBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = getItem(position)
        when (holder) {
            is UserViewHolder -> holder.bind(message)
            is AssistantViewHolder -> holder.bind(message, onRetryClick)
        }
    }

    class UserViewHolder(
        private val binding: ItemMessageUserBinding,
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(message: UiMessage) {
            binding.textContent.text = message.content
        }
    }

    class AssistantViewHolder(
        private val binding: ItemMessageAssistantBinding,
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(message: UiMessage, onRetryClick: () -> Unit) {
            val streaming = message.status == MessageStatus.STREAMING
            binding.textContent.text = when {
                message.content.isNotEmpty() && streaming -> message.content + CURSOR
                message.content.isNotEmpty() -> message.content
                streaming -> "正在输入$CURSOR"
                else -> "（空回复）"
            }

            // 每条回复的 token 消耗：输入 / 输出 / 缓存命中
            if (message.promptTokens > 0 || message.completionTokens > 0) {
                binding.textMeta.visibility = View.VISIBLE
                binding.textMeta.text = buildString {
                    append("输入 ${message.promptTokens} tok · 输出 ${message.completionTokens} tok")
                    if (message.cacheHitTokens > 0) append(" · 缓存 ${message.cacheHitTokens}")
                }
            } else {
                binding.textMeta.visibility = View.GONE
            }

            val hasError = message.status == MessageStatus.ERROR
            binding.textError.visibility = if (hasError) View.VISIBLE else View.GONE
            if (hasError) {
                binding.textError.text = "${message.error ?: "请求失败"} · 点这里重发"
                binding.textError.setOnClickListener { onRetryClick() }
                binding.cardBubble.setOnClickListener { onRetryClick() }
            } else {
                binding.textError.setOnClickListener(null)
                binding.cardBubble.setOnClickListener(null)
            }
        }
    }

    companion object {
        private const val TYPE_USER = 0
        private const val TYPE_ASSISTANT = 1
        private const val CURSOR = "▍"

        private val DIFF = object : DiffUtil.ItemCallback<UiMessage>() {
            override fun areItemsTheSame(oldItem: UiMessage, newItem: UiMessage): Boolean =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: UiMessage, newItem: UiMessage): Boolean =
                oldItem == newItem
        }
    }
}
