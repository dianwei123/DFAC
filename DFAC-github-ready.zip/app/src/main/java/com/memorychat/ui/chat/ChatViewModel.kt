package com.memorychat.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.memorychat.data.local.MessageEntity
import com.memorychat.data.local.MessageStatus
import com.memorychat.data.local.SessionEntity
import com.memorychat.data.repo.ChatRepository
import com.memorychat.data.repo.TurnPhase
import com.memorychat.data.repo.TurnSink
import com.memorychat.data.repo.TurnStatus
import com.memorychat.data.settings.AppSettings
import com.memorychat.data.settings.SettingsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** token 消耗组件的状态：常显，不会出现空白。 */
data class TokenStats(
    val contextTokens: Int = 0,
    val threshold: Int = AppSettings().tokenThreshold,
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
    val cacheHitRate: Double? = null,
    val compressedRounds: Int = 0,
    val savedTokens: Int = 0,
)

data class UiMessage(
    val id: Long,
    val role: String,
    val content: String,
    val status: String,
    val error: String? = null,
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
    val cacheHitTokens: Int = 0,
) {
    val isUser: Boolean get() = role == "user"
    val isStreaming: Boolean get() = status == MessageStatus.STREAMING
}

/** 侧边栏「历史对话」列表项。 */
data class SessionUi(
    val id: Long,
    val title: String,
    val updatedAt: Long,
    val compressedRounds: Int,
    val savedTokens: Int,
    val isCurrent: Boolean,
)

data class ChatUiState(
    val messages: List<UiMessage> = emptyList(),
    val sessions: List<SessionUi> = emptyList(),
    val statusText: String = "就绪",
    val tokens: TokenStats = TokenStats(),
    val phase: TurnPhase? = null,
    val banner: String? = null,
    val sending: Boolean = false,
    val llmEnabled: Boolean = true,
    val thinkingEnabled: Boolean = false,
    val webSearchEnabled: Boolean = false,
    val modeText: String = "",
    val errorEvent: String? = null,
)

/**
 * 聊天页 ViewModel：订阅 Room 消息流 + 承接仓库层的流式回调 + 维护 token 消耗组件。
 *
 * 气泡内容有两个来源（DB 每 350ms 落一次、sink 每个 chunk 推一次），
 * 合并时以「更长的流式内容」为准，避免 DB 的旧内容把新 chunk 盖回去。
 */
class ChatViewModel(
    private val repository: ChatRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel(), TurnSink {

    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    private var sessionId: Long = 0L
    private var observeJob: Job? = null
    private var cachedSessions: List<SessionEntity> = emptyList()

    init {
        viewModelScope.launch {
            sessionId = repository.ensureSession()
            observeMessages()
            refreshSessionInfo()
        }
        viewModelScope.launch {
            repository.observeSessions().collect { sessions ->
                cachedSessions = sessions
                publishSessions()
            }
        }
    }

    private fun observeMessages() {
        observeJob?.cancel()
        observeJob = viewModelScope.launch {
            repository.observeMessages(sessionId).collect { entities ->
                _state.update { current ->
                    current.copy(messages = merge(current.messages, entities))
                }
            }
        }
    }

    private fun publishSessions() {
        val currentId = sessionId
        _state.update { state ->
            state.copy(
                sessions = cachedSessions.map { session ->
                    SessionUi(
                        id = session.id,
                        title = session.title,
                        updatedAt = session.updatedAt,
                        compressedRounds = session.compressedRounds,
                        savedTokens = session.savedTokens,
                        isCurrent = session.id == currentId,
                    )
                },
            )
        }
    }

    /** 从侧边栏历史列表切换到某个会话。 */
    fun switchSession(targetId: Long) {
        if (_state.value.sending || targetId == sessionId) return
        viewModelScope.launch {
            sessionId = targetId
            observeMessages()
            publishSessions()
            _state.update {
                it.copy(
                    messages = emptyList(),
                    banner = null,
                    statusText = "已切换对话",
                    tokens = it.tokens.copy(
                        contextTokens = 0,
                        compressedRounds = 0,
                        savedTokens = 0,
                        promptTokens = 0,
                        completionTokens = 0,
                        cacheHitRate = null,
                    ),
                )
            }
            refreshSessionInfo()
        }
    }

    /** 删除会话；如果删的是当前会话，自动切到最近一个（没有就新建）。 */
    fun deleteSession(targetId: Long) {
        if (_state.value.sending) return
        viewModelScope.launch {
            repository.deleteSession(targetId)
            if (targetId == sessionId) {
                sessionId = repository.ensureSession()
                observeMessages()
                _state.update {
                    it.copy(messages = emptyList(), banner = null, statusText = "已删除当前对话")
                }
            }
            publishSessions()
            refreshSessionInfo()
        }
    }

    fun send(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || _state.value.sending) return
        viewModelScope.launch {
            _state.update {
                it.copy(
                    sending = true,
                    phase = TurnPhase.ESTIMATING,
                    statusText = "准备请求…",
                    errorEvent = null,
                    tokens = it.tokens.copy(promptTokens = 0, completionTokens = 0),
                )
            }
            try {
                repository.send(sessionId, trimmed, this@ChatViewModel)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(errorEvent = e.message ?: "发送失败") }
            } finally {
                _state.update { it.copy(sending = false) }
                refreshSessionInfo()
            }
        }
    }

    /** 重发生成失败的最后一轮（用户消息仍然保留）。 */
    fun retryLast() {
        if (_state.value.sending) return
        viewModelScope.launch {
            _state.update { it.copy(sending = true, errorEvent = null) }
            try {
                repository.regenerate(sessionId, this@ChatViewModel)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(errorEvent = e.message ?: "重试失败") }
            } finally {
                _state.update { it.copy(sending = false) }
                refreshSessionInfo()
            }
        }
    }

    fun clearConversation() {
        if (_state.value.sending) return
        viewModelScope.launch {
            repository.clearSession(sessionId)
            _state.update {
                it.copy(
                    messages = emptyList(),
                    banner = null,
                    tokens = it.tokens.copy(
                        contextTokens = 0,
                        compressedRounds = 0,
                        savedTokens = 0,
                        promptTokens = 0,
                        completionTokens = 0,
                        cacheHitRate = null,
                    ),
                )
            }
            refreshSessionInfo()
        }
    }

    fun newConversation() {
        if (_state.value.sending) return
        viewModelScope.launch {
            sessionId = repository.createSession()
            observeMessages()
            publishSessions()
            _state.update {
                it.copy(
                    messages = emptyList(),
                    banner = null,
                    statusText = "就绪",
                    phase = null,
                    tokens = it.tokens.copy(
                        contextTokens = 0,
                        compressedRounds = 0,
                        savedTokens = 0,
                        promptTokens = 0,
                        completionTokens = 0,
                        cacheHitRate = null,
                    ),
                )
            }
            refreshSessionInfo()
        }
    }

    /** 右侧抽屉里的「LLM 调用总开关」。 */
    fun setLlmEnabled(enabled: Boolean) {
        val current = settingsRepository.snapshot()
        if (current.llmEnabled == enabled) return
        settingsRepository.save(current.copy(llmEnabled = enabled))
        viewModelScope.launch {
            _state.update {
                it.copy(
                    llmEnabled = enabled,
                    modeText = modeLabel(settingsRepository.snapshot()),
                    statusText = if (enabled) "LLM 已开启" else "LLM 已关闭 · 消息只保存不请求",
                )
            }
            refreshSessionInfo()
        }
    }

    /** 输入框上方的「深度思考」快捷开关。 */
    fun setThinkingEnabled(enabled: Boolean) {
        val current = settingsRepository.snapshot()
        if (current.thinkingEnabled == enabled) return
        settingsRepository.save(current.copy(thinkingEnabled = enabled))
        _state.update {
            it.copy(
                thinkingEnabled = enabled,
                modeText = modeLabel(settingsRepository.snapshot()),
                statusText = if (enabled) {
                    "深度思考已开启 · 思考强度 ${current.reasoningEffort}（temperature 失效）"
                } else {
                    "深度思考已关闭"
                },
            )
        }
    }

    /** 输入框上方的「联网搜索」快捷开关（官方 deepseek_web_search，仅 deepseek-flash 支持）。 */
    fun setWebSearchEnabled(enabled: Boolean) {
        val current = settingsRepository.snapshot()
        if (current.webSearchEnabled == enabled) return
        var next = current.copy(webSearchEnabled = enabled)
        var notice = if (enabled) "联网搜索已开启 · 由模型决定是否搜索" else "联网搜索已关闭"
        if (enabled) {
            val flash = AppSettings.OFFICIAL_MODELS.first()
            if (current.model != flash) {
                next = next.copy(model = flash)
                notice = "联网搜索仅支持 $flash，已自动切换模型"
            }
            if (!current.thinkingEnabled) {
                notice += "（关闭思考时是普通联网搜索）"
            } else {
                notice += "（思考模式开启时是深度思考搜索）"
            }
        }
        settingsRepository.save(next)
        _state.update {
            it.copy(
                webSearchEnabled = enabled,
                modeText = modeLabel(next),
                statusText = notice,
            )
        }
    }

    fun refreshSessionInfo() {
        viewModelScope.launch {
            val settings = settingsRepository.snapshot()
            val session = repository.sessionSnapshot(sessionId)
            val contextTokens = repository.estimateContextTokens(sessionId)
            _state.update { current ->
                current.copy(
                    llmEnabled = settings.llmEnabled,
                    thinkingEnabled = settings.thinkingEnabled,
                    webSearchEnabled = settings.webSearchEnabled,
                    modeText = modeLabel(settings),
                    banner = session?.cacheDiag,
                    tokens = current.tokens.copy(
                        contextTokens = contextTokens,
                        threshold = settings.tokenThreshold,
                        compressedRounds = session?.compressedRounds ?: 0,
                        savedTokens = session?.savedTokens ?: 0,
                        cacheHitRate = session?.cacheHitRate?.takeIf { it > 0.0 },
                    ),
                    statusText = if (current.sending) {
                        current.statusText
                    } else {
                        idleStatus(settings, session)
                    },
                )
            }
        }
    }

    fun consumeError() {
        _state.update { it.copy(errorEvent = null) }
    }

    // ------------------------------------------------------------- TurnSink

    override suspend fun onAssistantText(messageId: Long, fullText: String) {
        _state.update { current ->
            current.copy(
                messages = current.messages.map { message ->
                    if (message.id == messageId && message.status == MessageStatus.STREAMING) {
                        message.copy(content = fullText)
                    } else {
                        message
                    }
                },
            )
        }
    }

    override suspend fun onStatus(status: TurnStatus) {
        _state.update { current ->
            current.copy(
                statusText = status.message,
                phase = status.phase,
                banner = when {
                    status.phase == TurnPhase.CACHE_CHECK -> status.message
                    status.degraded -> "本轮已降级：摘要生成失败/超时，改用原文转发（fail-open）"
                    else -> current.banner
                },
                tokens = current.tokens.copy(
                    contextTokens = if (status.contextTokens > 0) {
                        status.contextTokens
                    } else {
                        current.tokens.contextTokens
                    },
                    promptTokens = if (status.promptTokens > 0) {
                        status.promptTokens
                    } else {
                        current.tokens.promptTokens
                    },
                    completionTokens = if (status.completionTokens > 0) {
                        status.completionTokens
                    } else {
                        current.tokens.completionTokens
                    },
                    cacheHitRate = status.cacheHitRate ?: current.tokens.cacheHitRate,
                    compressedRounds = if (status.compressedRounds > 0) {
                        status.compressedRounds
                    } else {
                        current.tokens.compressedRounds
                    },
                    savedTokens = if (status.savedTokens > 0) {
                        status.savedTokens
                    } else {
                        current.tokens.savedTokens
                    },
                ),
            )
        }
    }

    override suspend fun onError(message: String, retryable: Boolean) {
        _state.update { current ->
            current.copy(
                errorEvent = if (retryable) "$message（可点气泡重发）" else message,
                sending = false,
            )
        }
    }

    // -------------------------------------------------------------- helpers

    private fun modeLabel(settings: AppSettings): String = when {
        !settings.llmEnabled -> "LLM 已关闭 · 仅保存消息"
        settings.isMockMode -> "离线 Mock · 未配置 API Key"
        else -> buildString {
            append("在线 · ${settings.model}")
            append(
                if (settings.thinkingEnabled) {
                    " · 思考 ${settings.reasoningEffort}"
                } else {
                    " · 非思考"
                },
            )
            if (settings.webSearchEnabled) append(" · 联网")
        }
    }

    private fun idleStatus(settings: AppSettings, session: SessionEntity?): String = when {
        !settings.llmEnabled -> "LLM 已关闭 · 消息只保存不请求"
        else -> buildString {
            append("已压缩 ${session?.compressedRounds ?: 0} 轮")
            append(" · 节省 ${session?.savedTokens ?: 0} tokens")
        }
    }

    private fun merge(current: List<UiMessage>, entities: List<MessageEntity>): List<UiMessage> {
        val localById = current.associateBy { it.id }
        return entities.map { entity ->
            val incoming = entity.toUi()
            val previous = localById[entity.id]
            if (previous != null &&
                incoming.isStreaming &&
                previous.isStreaming &&
                previous.content.length > incoming.content.length
            ) {
                incoming.copy(content = previous.content)
            } else {
                incoming
            }
        }
    }

    private fun MessageEntity.toUi(): UiMessage = UiMessage(
        id = id,
        role = role,
        content = content,
        status = status,
        error = errorMessage,
        promptTokens = promptTokens,
        completionTokens = completionTokens,
        cacheHitTokens = cacheHitTokens,
    )
}
