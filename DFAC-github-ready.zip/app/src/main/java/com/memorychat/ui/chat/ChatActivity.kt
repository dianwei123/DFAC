package com.memorychat.ui.chat

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.memorychat.BuildConfig
import com.memorychat.R
import com.memorychat.data.settings.AppSettings
import com.memorychat.databinding.ActivityChatBinding
import com.memorychat.di.ServiceLocator
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

/**
 * 聊天主界面。
 *
 * - 设置全部放在**右侧滑出侧边栏**（DrawerLayout，gravity=end）
 * - 顶部常显 token 消耗组件（上下文 / 本轮 / 缓存 / 压缩节省）
 * - 输入区通过 WindowInsets(ime) 下内边距避让软键盘
 * - 抽屉里有「LLM 调用总开关」，关闭后不发起任何模型请求
 */
class ChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatBinding
    private lateinit var adapter: MessageAdapter
    private lateinit var sessionAdapter: SessionAdapter
    private var autoScroll = true
    private var suppressDrawerCallbacks = false
    private var syncingToggles = false

    private val settingsRepository get() = ServiceLocator.settingsRepository

    private val viewModel: ChatViewModel by viewModels {
        viewModelFactory {
            initializer {
                ChatViewModel(ServiceLocator.repository, ServiceLocator.settingsRepository)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        applyWindowInsets()
        setupRecycler()
        setupInput()
        setupDrawer()
        setupBackHandling()
        observeState()
    }

    // ------------------------------------------------------------ 系统栏 / 键盘

    private fun applyWindowInsets() {
        WindowInsetsControllerCompat(window, binding.root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = true
        }
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            // 状态栏高度做进 Toolbar / 抽屉头部背景里，保证顶部整条都是品牌色
            binding.toolbar.updatePadding(top = bars.top)
            binding.drawerHeader.updatePadding(top = bars.top)
            // 底部按「导航栏 / 软键盘」的较大者避让，输入框不会再被键盘挡住
            binding.root.updatePadding(
                left = bars.left,
                right = bars.right,
                bottom = maxOf(bars.bottom, ime.bottom),
            )
            if (ime.bottom > 0 && autoScroll) scrollToBottom()
            insets
        }
    }

    // ---------------------------------------------------------------- 列表 / 输入

    private fun setupRecycler() {
        adapter = MessageAdapter(onRetryClick = { viewModel.retryLast() })
        val layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        binding.recyclerMessages.layoutManager = layoutManager
        binding.recyclerMessages.adapter = adapter
        binding.recyclerMessages.addOnScrollListener(
            object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    autoScroll = layoutManager.findLastVisibleItemPosition() >=
                        adapter.itemCount - 2
                }
            },
        )
    }

    private fun setupInput() {
        binding.buttonSend.setOnClickListener { submit() }
        binding.editInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submit()
                true
            } else {
                false
            }
        }
        binding.editInput.doAfterTextChanged { text ->
            binding.buttonSend.isEnabled = !viewModel.state.value.sending && !text.isNullOrBlank()
        }
        binding.editInput.requestFocus()
    }

    private fun submit() {
        val text = binding.editInput.text?.toString().orEmpty()
        if (text.isBlank()) return
        binding.editInput.setText("")
        autoScroll = true
        viewModel.send(text)
    }

    private fun scrollToBottom() {
        binding.recyclerMessages.post {
            val count = adapter.itemCount
            if (count > 0) binding.recyclerMessages.scrollToPosition(count - 1)
        }
    }

    // ---------------------------------------------------------------- 抽屉 / 设置

    private fun setupDrawer() {
        applyModelOptions(cachedModelOptions())
        loadSettingsForm()
        setupSidebarPages()

        binding.buttonSave.setOnClickListener {
            saveSettingsForm(showToast = true)
            viewModel.refreshSessionInfo()
        }
        binding.buttonTest.setOnClickListener { testConnection() }
        binding.buttonClearKey.setOnClickListener {
            settingsRepository.clearApiKey()
            binding.editApiKey.setText("")
            updateDrawerMode("已清除 API Key")
            viewModel.refreshSessionInfo()
        }
        binding.switchLlm.setOnCheckedChangeListener { _, _ ->
            if (suppressDrawerCallbacks || syncingToggles) return@setOnCheckedChangeListener
            // 立即生效，不需要再点保存
            saveSettingsForm(showToast = false)
            viewModel.refreshSessionInfo()
            updateDrawerMode(null)
        }
        binding.switchThinking.setOnCheckedChangeListener { _, _ ->
            if (suppressDrawerCallbacks || syncingToggles) return@setOnCheckedChangeListener
            saveSettingsForm(showToast = false)
            viewModel.refreshSessionInfo()
        }
        // 输入框上方的两个快捷开关：联网搜索 / 深度思考
        binding.switchWebSearchQuick.setOnCheckedChangeListener { _, checked ->
            if (syncingToggles) return@setOnCheckedChangeListener
            viewModel.setWebSearchEnabled(checked)
            loadSettingsForm()
        }
        binding.switchThinkingQuick.setOnCheckedChangeListener { _, checked ->
            if (syncingToggles) return@setOnCheckedChangeListener
            viewModel.setThinkingEnabled(checked)
            loadSettingsForm()
        }
        binding.editReasoningEffort.setOnItemClickListener { _, _, _, _ ->
            if (suppressDrawerCallbacks) return@setOnItemClickListener
            saveSettingsForm(showToast = false)
        }
        binding.switchTools.setOnCheckedChangeListener { _, _ ->
            if (suppressDrawerCallbacks) return@setOnCheckedChangeListener
            saveSettingsForm(showToast = false)
        }
        binding.buttonNewChat.setOnClickListener {
            viewModel.newConversation()
            closeDrawer()
            toast("已新建对话，压缩统计已重置")
        }
        binding.buttonClearChat.setOnClickListener {
            viewModel.clearConversation()
            closeDrawer()
            toast("已清空当前对话")
        }
        updateDrawerMode(null)
    }

    /** 侧边栏两页：历史对话 / 设置（默认落在历史对话）。 */
    private fun setupSidebarPages() {
        sessionAdapter = SessionAdapter(
            onSwitch = { id ->
                viewModel.switchSession(id)
                closeDrawer()
                toast("已切换对话")
            },
            onDelete = { id -> confirmDeleteSession(id) },
        )
        binding.recyclerSessions.layoutManager = LinearLayoutManager(this)
        binding.recyclerSessions.adapter = sessionAdapter

        binding.buttonNewChatHistory.setOnClickListener {
            viewModel.newConversation()
            closeDrawer()
            toast("已新建对话")
        }
        binding.togglePages.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            showSidebarPage(settings = checkedId == R.id.buttonPageSettings)
        }
        binding.togglePages.check(R.id.buttonPageHistory)
        showSidebarPage(settings = false)
        binding.textVersion.text =
            "版本 v${BuildConfig.VERSION_NAME}（versionCode ${BuildConfig.VERSION_CODE}）"
    }

    private fun showSidebarPage(settings: Boolean) {
        binding.pageHistory.visibility = if (settings) View.GONE else View.VISIBLE
        binding.pageSettings.visibility = if (settings) View.VISIBLE else View.GONE
    }

    private fun cachedModelOptions(): List<String> =
        settingsRepository.availableModels().ifEmpty { AppSettings.OFFICIAL_MODELS }

    private fun confirmDeleteSession(sessionId: Long) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.session_delete_title)
            .setMessage(R.string.session_delete_message)
            .setNegativeButton(R.string.session_delete_cancel, null)
            .setPositiveButton(R.string.session_delete_confirm) { _, _ ->
                viewModel.deleteSession(sessionId)
                toast("已删除该对话")
            }
            .show()
    }

    /** 模型下拉选项：官方默认两个 + 运行时从 GET /models 拿到的 + 当前已选。 */
    private fun applyModelOptions(models: List<String>, keepCurrent: String? = null) {
        val current = keepCurrent ?: binding.editModel.text?.toString().orEmpty()
        val merged = LinkedHashSet<String>()
        if (current.isNotBlank()) merged += current
        models.forEach { merged += it }
        AppSettings.OFFICIAL_MODELS.forEach { merged += it }
        binding.editModel.setAdapter(
            ArrayAdapter(
                this,
                android.R.layout.simple_dropdown_item_1line,
                merged.toList(),
            ),
        )
        if (current.isNotBlank()) binding.editModel.setText(current, false)
    }

    private fun loadSettingsForm() {
        val settings = settingsRepository.snapshot()
        applyModelOptions(cachedModelOptions(), keepCurrent = settings.model)
        suppressDrawerCallbacks = true
        syncingToggles = true
        binding.editApiKey.setText(settings.apiKey)
        binding.editBaseUrl.setText(settings.baseUrl)
        binding.editModel.setText(settings.model, false)
        binding.editTokenThreshold.setText(settings.tokenThreshold.toString())
        binding.editRecentRounds.setText(settings.recentRounds.toString())
        binding.editTemperature.setText(formatNumber(settings.temperature))
        binding.editMaxTokens.setText(settings.maxTokens.toString())
        binding.editCacheFloor.setText((settings.cacheHitFloor * 100).toInt().toString())
        binding.editSummaryTimeout.setText((settings.summaryTimeoutMs / 1000).toString())
        binding.switchLlm.isChecked = settings.llmEnabled
        binding.switchTools.isChecked = settings.toolsEnabled
        binding.switchThinking.isChecked = settings.thinkingEnabled
        binding.editReasoningEffort.setText(settings.reasoningEffort, false)
        binding.switchWebSearchQuick.isChecked = settings.webSearchEnabled
        binding.switchThinkingQuick.isChecked = settings.thinkingEnabled
        syncingToggles = false
        suppressDrawerCallbacks = false
    }

    private fun currentFormSettings(): AppSettings {
        val defaults = settingsRepository.snapshot()
        return AppSettings(
            apiKey = binding.editApiKey.text?.toString().orEmpty().trim(),
            baseUrl = binding.editBaseUrl.text?.toString().orEmpty().trim()
                .ifBlank { defaults.baseUrl },
            model = binding.editModel.text?.toString().orEmpty().trim()
                .ifBlank { defaults.model },
            tokenThreshold = binding.editTokenThreshold.text?.toString()?.toIntOrNull()
                ?.coerceIn(500, 200_000) ?: defaults.tokenThreshold,
            recentRounds = binding.editRecentRounds.text?.toString()?.toIntOrNull()
                ?.coerceIn(1, 20) ?: defaults.recentRounds,
            temperature = binding.editTemperature.text?.toString()?.toDoubleOrNull()
                ?.coerceIn(0.0, 2.0) ?: defaults.temperature,
            topP = defaults.topP,
            maxTokens = binding.editMaxTokens.text?.toString()?.toIntOrNull()
                ?.coerceIn(64, 393_216) ?: defaults.maxTokens,
            cacheHitFloor = (binding.editCacheFloor.text?.toString()?.toDoubleOrNull()
                ?: (defaults.cacheHitFloor * 100)).coerceIn(0.0, 100.0) / 100.0,
            summaryTimeoutMs = (binding.editSummaryTimeout.text?.toString()?.toLongOrNull()
                ?.coerceIn(5, 120) ?: (defaults.summaryTimeoutMs / 1000)) * 1000,
            maxRetries = defaults.maxRetries,
            toolsEnabled = binding.switchTools.isChecked,
            maxToolRounds = defaults.maxToolRounds,
            llmEnabled = binding.switchLlm.isChecked,
            thinkingEnabled = binding.switchThinking.isChecked,
            reasoningEffort = binding.editReasoningEffort.text?.toString().orEmpty()
                .ifBlank { defaults.reasoningEffort },
            webSearchEnabled = binding.switchWebSearchQuick.isChecked,
        )
    }

    private fun saveSettingsForm(showToast: Boolean) {
        settingsRepository.save(currentFormSettings())
        updateDrawerMode(null)
        if (showToast) toast(getString(R.string.settings_saved))
    }

    private fun updateDrawerMode(prefix: String?) {
        val settings = settingsRepository.snapshot()
        val mode = buildString {
            when {
                !settings.llmEnabled -> append("LLM 调用：已关闭 · 消息只保存不请求")
                settings.isMockMode -> append("LLM 调用：离线 Mock（未填 API Key）")
                else -> append("LLM 调用：在线 · ${settings.model} · Key ${settingsRepository.maskedApiKey()}")
            }
            if (settings.llmEnabled && !settings.isMockMode) {
                append(if (settings.thinkingEnabled) " · 思考 ${settings.reasoningEffort}" else " · 非思考")
                if (settings.webSearchEnabled) append(" · 联网搜索")
            }
        }
        binding.textMode.text = if (prefix.isNullOrBlank()) mode else "$prefix\n$mode"
    }

    private fun testConnection() {
        saveSettingsForm(showToast = false)
        val settings = settingsRepository.snapshot()
        if (!settings.llmEnabled) {
            updateDrawerMode("LLM 调用总开关已关闭，先打开再测试连接")
            return
        }
        binding.progressTest.visibility = View.VISIBLE
        binding.textMode.text = if (settings.isMockMode) {
            "当前为离线 Mock，正在本地生成测试回复…"
        } else {
            "正在 GET ${settings.modelsEndpoint} 校验模型，再发一次对话…"
        }
        lifecycleScope.launch {
            try {
                val result = withTimeout(40_000L) { ServiceLocator.repository.probeConnection() }
                // 用服务端真实可用模型刷新下拉，避免选了已下线的模型名
                applyModelOptions(result.availableModels, keepCurrent = result.activeModel)
                binding.editModel.setText(result.activeModel, false)
                val switchedNote = if (result.autoSwitched) {
                    "\n已自动把模型切换到可用项：${result.activeModel}（原模型不可用）"
                } else {
                    ""
                }
                binding.textMode.text = buildString {
                    append("连接成功 · 当前模型：${result.activeModel}")
                    append("\n可用模型：${result.availableModels.joinToString(" / ")}")
                    append(switchedNote)
                    append("\n模型回复：${result.reply}")
                }
            } catch (e: Exception) {
                binding.textMode.text = "连接失败：${e.message ?: e.javaClass.simpleName}" +
                    "\n请检查 API Key / Base URL / 模型是否在可用列表内"
            } finally {
                binding.progressTest.visibility = View.GONE
            }
        }
    }

    private fun openDrawer(settingsPage: Boolean = false) {
        showSidebarPage(settings = settingsPage)
        binding.togglePages.check(
            if (settingsPage) R.id.buttonPageSettings else R.id.buttonPageHistory,
        )
        binding.drawerLayout.openDrawer(GravityCompat.END)
    }

    private fun closeDrawer() {
        if (binding.drawerLayout.isDrawerOpen(GravityCompat.END)) {
            binding.drawerLayout.closeDrawer(GravityCompat.END)
        }
    }

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (binding.drawerLayout.isDrawerOpen(GravityCompat.END)) {
                        closeDrawer()
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            },
        )
    }

    // ---------------------------------------------------------------- 菜单

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_chat, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_drawer -> {
            // 工具栏按钮 = 打开侧边栏（历史对话页）
            openDrawer(settingsPage = false)
            true
        }

        R.id.action_new_chat -> {
            viewModel.newConversation()
            toast("已新建对话，压缩统计已重置")
            true
        }

        R.id.action_clear -> {
            viewModel.clearConversation()
            toast("已清空当前对话")
            true
        }

        else -> super.onOptionsItemSelected(item)
    }

    // ---------------------------------------------------------------- 渲染

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collect { render(it) }
            }
        }
    }

    private fun render(state: ChatUiState) {
        supportActionBar?.subtitle = state.modeText
        binding.textStatus.text = state.statusText

        // token 消耗组件：始终有值
        binding.chipContext.text = "上下文 ${state.tokens.contextTokens} / ${state.tokens.threshold} tok"
        binding.chipTurn.text = "本轮 入 ${state.tokens.promptTokens} / 出 ${state.tokens.completionTokens} tok"
        binding.chipCache.text = state.tokens.cacheHitRate?.let { rate ->
            "缓存命中 ${(rate * 100).toInt()}%"
        } ?: "缓存命中 —"
        binding.chipCompress.text =
            "压缩 ${state.tokens.compressedRounds} 轮 · 省 ${state.tokens.savedTokens}"

        binding.textEmpty.visibility = if (state.messages.isEmpty()) View.VISIBLE else View.GONE
        binding.cardBanner.visibility =
            if (state.banner.isNullOrBlank()) View.GONE else View.VISIBLE
        binding.textBanner.text = state.banner.orEmpty()
        binding.textBanner.setOnClickListener { toast(state.banner.orEmpty()) }
        binding.progressSending.visibility =
            if (state.sending) View.VISIBLE else View.GONE
        binding.buttonSend.isEnabled = !state.sending && !binding.editInput.text.isNullOrBlank()

        // 抽屉开关与状态保持同步（例如从设置里改了 LLM 开关 / 快捷键切换了思考、联网）
        syncSwitch(binding.switchLlm, state.llmEnabled)
        syncSwitch(binding.switchThinking, state.thinkingEnabled)
        syncSwitch(binding.switchWebSearchQuick, state.webSearchEnabled)
        syncSwitch(binding.switchThinkingQuick, state.thinkingEnabled)

        // 侧边栏历史对话列表
        sessionAdapter.submitList(state.sessions)
        binding.textNoSessions.visibility =
            if (state.sessions.isEmpty()) View.VISIBLE else View.GONE

        adapter.submitList(state.messages) {
            if (autoScroll && state.messages.isNotEmpty()) scrollToBottom()
        }

        state.errorEvent?.let { message ->
            toast(message)
            viewModel.consumeError()
        }
    }

    private fun toast(message: String) {
        if (message.isBlank()) return
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    /** 程序化同步开关状态，避免触发监听器造成回写循环。 */
    private fun syncSwitch(button: android.widget.CompoundButton, checked: Boolean) {
        if (button.isChecked == checked) return
        syncingToggles = true
        button.isChecked = checked
        syncingToggles = false
    }

    /** Float→Double 会带出 1.299999952316 这种尾巴，这里去掉无意义的尾零。 */
    private fun formatNumber(value: Double): String =
        java.math.BigDecimal.valueOf(value).stripTrailingZeros().toPlainString()
}
