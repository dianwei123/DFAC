package com.memorychat.network

import com.memorychat.domain.PrefixHash
import com.memorychat.domain.RetryPolicy
import com.memorychat.domain.UsageSnapshot
import com.memorychat.domain.model.ChatMessage
import com.memorychat.domain.model.Role
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * 离线 Mock 客户端：没填 API Key 时启用，用来验证整条链路
 * （压缩 → 摘要 → 组装 → 流式渲染 → usage/缓存体检 → 状态条）而不消耗额度。
 *
 * 行为尽量贴近真实接口：分片吐字、给出 usage、并对「带摘要的请求」返回更高的缓存命中率。
 */
class MockChatCompletionClient : ChatCompletionClient {

    override fun stream(
        request: ChatCompletionRequest,
        retryPolicy: RetryPolicy,
    ): Flow<StreamEvent> = flow {
        val lastUser = request.messages.lastOrNull { it.role == Role.USER }?.content.orEmpty()
        val hasSummaryPrefix = request.messages.any {
            it.role == Role.SYSTEM && it.content.contains("摘要")
        }
        val reply = buildReply(lastUser, hasSummaryPrefix, request.messages.any { it.role == Role.SYSTEM })
        val chunks = reply.chunked(MOCK_CHUNK_SIZE)
        chunks.forEachIndexed { index, chunk ->
            delay(if (index == 0) 160 else 45)
            emit(StreamEvent.Delta(chunk))
        }
        // 模拟 DeepSeek 的 usage：首轮/前缀变化时命中率低，稳定前缀下命中率高。
        val promptTokens = estimatePromptTokens(request)
        val hitTokens = if (hasSummaryPrefix) {
            (promptTokens * 0.82).toInt()
        } else {
            (promptTokens * 0.35).toInt()
        }
        emit(
            StreamEvent.UsageReported(
                UsageSnapshot(
                    promptTokens = promptTokens,
                    completionTokens = reply.length / 2,
                    cacheHitTokens = hitTokens,
                    cacheMissTokens = promptTokens - hitTokens,
                ),
            ),
        )
        emit(StreamEvent.Completed("stop"))
    }

    override suspend fun complete(request: ChatCompletionRequest): CompletionResult {
        delay(120)
        val system = request.messages.firstOrNull { it.role == Role.SYSTEM }?.content.orEmpty()
        val user = request.messages.lastOrNull { it.role == Role.USER }?.content.orEmpty()
        val text = if (system.contains("摘要器") || user.contains("压缩")) {
            buildMockSummary(user)
        } else {
            "（Mock）收到：${user.take(60)}"
        }
        return CompletionResult(
            text = text,
            usage = UsageSnapshot(promptTokens = 120, completionTokens = text.length / 2),
            finishReason = "stop",
        )
    }

    override suspend fun listModels(): List<String> =
        listOf("deepseek-flash", "deepseek-v4-pro")

    override fun close() = Unit

    private fun buildReply(
        lastUser: String,
        hasSummaryPrefix: Boolean,
        hasSystem: Boolean,
    ): String {
        val cleaned = lastUser.replace(Regex("\\[上下文压缩指令][\\s\\S]*$"), "").trim()
        val quoted = cleaned.take(40).ifBlank { "刚刚那句" }
        val memoryHint = if (hasSummaryPrefix) "我还记得咱们前面聊的那些。" else ""
        val systemHint = if (hasSystem) "" else "（没有收到 system prompt）"
        return buildString {
            append("（离线 Mock 模式）")
            append(memoryHint)
            append(systemHint)
            append("你说「$quoted」，我听到啦。")
            append("这里是本地模拟的流式回复，用来验证压缩、重试和气泡渲染链路。")
            append("在设置页填入真实 DeepSeek API Key 之后，就会走真实接口。")
        }
    }

    private fun buildMockSummary(transcript: String): String {
        val lines = transcript.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        val userLines = lines.filter { it.startsWith("用户") }.map { it.removePrefix("用户：") }
        val digest = userLines.take(6).joinToString("；") { it.take(24) }
        return buildString {
            append("【Mock 摘要】更早的对话共 ${lines.size} 条。")
            append("用户主要聊到：")
            append(digest.ifBlank { "（无有效内容）" })
            append("。语气偏日常闲聊，未完成的约定：无。")
            append("（本摘要由本地 Mock 生成，用于演示 summary_cache 冻结逻辑）")
        }
    }

    private fun estimatePromptTokens(request: ChatCompletionRequest): Int =
        request.messages.sumOf { it.content.length / 2 } + PrefixHash.of(
            request.messages.mapIndexed { index, message ->
                ChatMessage(id = index.toLong(), role = message.role, content = message.content)
            },
        ).length

    companion object {
        private const val MOCK_CHUNK_SIZE = 3
    }
}
