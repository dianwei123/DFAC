package com.memorychat.network

import com.memorychat.data.settings.AppSettings
import com.memorychat.domain.RetryPolicy
import com.memorychat.domain.UsageSnapshot
import com.memorychat.domain.model.Role
import com.memorychat.domain.model.ToolCall
import com.memorychat.domain.model.ToolSpec
import com.memorychat.domain.model.WireMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * 真实 DeepSeek 客户端（架构图节点「OkHttp 发起 SSE 请求 DeepSeek API」）。
 *
 * 用 OkHttp 同步 `execute()` + 手动逐行解析 SSE：比回调式 EventSource 更好控制
 * 「chunk → 气泡」的时序，也方便在出错时区分「尚未输出任何内容（可重试）」和
 * 「已经吐了半截（不能重试，否则会把重复内容拼进气泡）」。
 */
class DeepSeekHttpClient(
    private val settingsProvider: () -> AppSettings,
    private val client: OkHttpClient = defaultClient(),
) : ChatCompletionClient {

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    override fun stream(
        request: ChatCompletionRequest,
        retryPolicy: RetryPolicy,
    ): Flow<StreamEvent> = flow {
        var attempt = 0
        var emittedAnyContent = false
        while (true) {
            attempt++
            try {
                attemptStream(request).collect { event ->
                    if (event is StreamEvent.Delta && event.text.isNotEmpty()) {
                        emittedAnyContent = true
                    }
                    emit(event)
                }
                return@flow
            } catch (e: ApiException) {
                val canRetry = e.retryable && !emittedAnyContent &&
                    retryPolicy.hasAttemptsLeft(attempt)
                if (!canRetry) throw e
                emit(
                    StreamEvent.Retrying(
                        attempt = attempt,
                        maxAttempts = retryPolicy.maxAttempts,
                        statusCode = e.statusCode,
                        reason = e.message,
                    ),
                )
                delay(retryPolicy.delayMillisFor(attempt))
            } catch (e: IOException) {
                val canRetry = !emittedAnyContent && retryPolicy.hasAttemptsLeft(attempt)
                if (!canRetry) throw e
                emit(
                    StreamEvent.Retrying(
                        attempt = attempt,
                        maxAttempts = retryPolicy.maxAttempts,
                        statusCode = null,
                        reason = e.message ?: "网络异常",
                    ),
                )
                delay(retryPolicy.delayMillisFor(attempt))
            }
        }
    }

    /**
     * 非流式请求。
     *
     * 注意：OkHttp 的 `execute()` 是阻塞调用，必须切到 IO 线程执行，
     * 否则在 UI 线程调用（例如设置页「测试连接」）会抛
     * `NetworkOnMainThreadException`。这里用 [withContext] 保证线程正确，
     * 不依赖调用方自己切线程。
     */
    override suspend fun complete(request: ChatCompletionRequest): CompletionResult =
        withContext(Dispatchers.IO) {
            val settings = settingsProvider()
            val payload = buildPayload(request)
            val httpRequest = newHttpRequest(settings, payload)
            client.newCall(httpRequest).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw ApiException(response.code, humanReadableError(response.code, raw))
                }
                val root = JSONObject(raw)
                val choice = root.optJSONArray("choices")?.optJSONObject(0)
                val message = choice?.optJSONObject("message")
                CompletionResult(
                    text = message?.optString("content").orEmpty(),
                    usage = parseUsage(root),
                    toolCalls = parseToolCalls(message?.optJSONArray("tool_calls")),
                    finishReason = choice?.optString("finish_reason"),
                )
            }
        }

    /** GET /models，列出当前 Key 可用的模型 ID。 */
    override suspend fun listModels(): List<String> = withContext(Dispatchers.IO) {
        val settings = settingsProvider()
        val request = Request.Builder()
            .url(settings.modelsEndpoint)
            .header("Authorization", "Bearer ${settings.apiKey.trim()}")
            .header("Accept", "application/json")
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw ApiException(response.code, humanReadableError(response.code, raw))
            }
            val data = runCatching { JSONObject(raw).optJSONArray("data") }.getOrNull()
            buildList {
                if (data != null) {
                    for (index in 0 until data.length()) {
                        val id = data.optJSONObject(index)?.optString("id").orEmpty()
                        if (id.isNotBlank()) add(id)
                    }
                }
            }
        }
    }

    override fun close() {
        client.dispatcher.executorService.shutdown()
        client.connectionPool.evictAll()
    }

    // ---------------------------------------------------------------- 流式解析

    private fun attemptStream(request: ChatCompletionRequest): Flow<StreamEvent> = flow {
        val settings = settingsProvider()
        val payload = buildPayload(request)
        val httpRequest = newHttpRequest(settings, payload)
        client.newCall(httpRequest).execute().use { response ->
            if (!response.isSuccessful) {
                val raw = response.body?.string().orEmpty()
                throw ApiException(response.code, humanReadableError(response.code, raw))
            }
            val source = response.body?.source() ?: throw IOException("响应体为空")
            val toolCallAccumulator = ToolCallAccumulator()
            val webSources = linkedMapOf<String, String>()
            var finishReason: String? = null

            while (true) {
                val line = source.readUtf8Line() ?: break
                if (line.isBlank() || !line.startsWith(DATA_PREFIX)) continue
                val data = line.removePrefix(DATA_PREFIX).trim()
                if (data.isEmpty() || data == DONE_SENTINEL) break
                val chunk = runCatching { JSONObject(data) }.getOrNull() ?: continue

                parseUsage(chunk)?.let { emit(StreamEvent.UsageReported(it)) }

                val choice = chunk.optJSONArray("choices")?.optJSONObject(0) ?: continue
                choice.optString("finish_reason").takeIf { it.isNotBlank() }?.let {
                    finishReason = it
                }

                // 联网工具过程事件（choice 上与 delta 并列）
                choice.optJSONObject("server_tool_event")?.let { event ->
                    describeWebToolEvent(event)?.let { emit(StreamEvent.WebToolEvent(it)) }
                    collectSources(event.optJSONObject("call"), webSources)
                }

                val delta = choice.optJSONObject("delta") ?: continue
                // 思考模式会先下发 reasoning_content，再下发 content，二者要分开处理
                val reasoning = delta.optString("reasoning_content", "")
                if (reasoning.isNotEmpty()) emit(StreamEvent.Reasoning(reasoning))
                val text = delta.optString("content", "")
                if (text.isNotEmpty()) emit(StreamEvent.Delta(text))
                delta.optJSONArray("tool_calls")?.let { toolCallAccumulator.merge(it) }

                // 最后一个 chunk 的 delta 里会带完整 server_tool_calls 与 annotations
                delta.optJSONArray("server_tool_calls")?.let { steps ->
                    for (index in 0 until steps.length()) {
                        val calls = steps.optJSONObject(index)?.optJSONArray("calls")
                        if (calls != null) {
                            for (callIndex in 0 until calls.length()) {
                                collectSources(calls.optJSONObject(callIndex), webSources)
                            }
                        }
                    }
                }
                delta.optJSONArray("annotations")?.let { annotations ->
                    for (index in 0 until annotations.length()) {
                        val citation = annotations.optJSONObject(index)
                            ?.optJSONObject("url_citation") ?: continue
                        val url = citation.optString("url")
                        if (url.isNotBlank()) {
                            webSources.putIfAbsent(url, citation.optString("title").ifBlank { url })
                        }
                    }
                }
            }

            if (webSources.isNotEmpty()) {
                emit(
                    StreamEvent.Sources(
                        webSources.map { (url, title) -> WebSource(title = title, url = url) },
                    ),
                )
            }
            val calls = toolCallAccumulator.build()
            if (calls.isNotEmpty()) emit(StreamEvent.ToolCallRequested(calls))
            emit(StreamEvent.Completed(finishReason))
        }
    }.flowOn(Dispatchers.IO)

    // ---------------------------------------------------------------- HTTP / JSON

    private fun newHttpRequest(settings: AppSettings, payload: String): Request {
        val body: RequestBody = payload.toRequestBody(jsonMediaType)
        return Request.Builder()
            .url(settings.endpoint)
            .header("Authorization", "Bearer ${settings.apiKey.trim()}")
            .header("Accept", "text/event-stream")
            .header("Content-Type", "application/json")
            .post(body)
            .build()
    }

    private fun buildPayload(request: ChatCompletionRequest): String {
        val root = JSONObject()
        root.put("model", request.model)
        root.put("temperature", request.temperature)
        root.put("stream", request.stream)
        request.topP?.let { root.put("top_p", it) }
        request.maxTokens?.let { root.put("max_tokens", it) }
        if (request.stream) {
            // DeepSeek 流式默认不回 usage，需要显式要求；否则拿不到 prompt_cache_hit_tokens。
            root.put("stream_options", JSONObject().put("include_usage", true))
        }
        root.put("messages", messagesToJson(request.messages))
        if (request.webSearchEnabled) {
            // 官方服务端联网工具：不能与 function 工具混用，也不能用 tool_choice 指定
            root.put("tools", JSONArray().put(JSONObject().put("type", "deepseek_web_search")))
        } else if (request.tools.isNotEmpty()) {
            root.put("tools", toolsToJson(request.tools))
            root.put("tool_choice", "auto")
        }
        // 官方 thinking 参数：{"type":"enabled"|"disabled"}；thinking 优先于 reasoning_effort
        request.thinkingEnabled?.let { enabled ->
            root.put("thinking", JSONObject().put("type", if (enabled) "enabled" else "disabled"))
            if (enabled && !request.reasoningEffort.isNullOrBlank()) {
                root.put("reasoning_effort", request.reasoningEffort)
            }
        }
        return root.toString()
    }

    private fun messagesToJson(messages: List<WireMessage>): JSONArray {
        val array = JSONArray()
        messages.forEach { message ->
            val item = JSONObject()
            item.put("role", message.role.wire)
            if (message.role == Role.TOOL) {
                item.put("content", message.content)
                message.toolCallId?.let { item.put("tool_call_id", it) }
            } else if (message.toolCalls.isNotEmpty()) {
                item.put("content", message.content.ifBlank { JSONObject.NULL })
                item.put("tool_calls", toolCallsToJson(message.toolCalls))
            } else {
                item.put("content", message.content)
            }
            array.put(item)
        }
        return array
    }

    private fun toolCallsToJson(calls: List<ToolCall>): JSONArray {
        val array = JSONArray()
        calls.forEach { call ->
            array.put(
                JSONObject()
                    .put("id", call.id)
                    .put("type", "function")
                    .put(
                        "function",
                        JSONObject().put("name", call.name).put("arguments", call.argumentsJson),
                    ),
            )
        }
        return array
    }

    private fun toolsToJson(tools: List<ToolSpec>): JSONArray {
        val array = JSONArray()
        tools.forEach { tool ->
            val parameters = runCatching { JSONObject(tool.parametersJson) }
                .getOrElse { JSONObject("{\"type\":\"object\",\"properties\":{}}") }
            array.put(
                JSONObject()
                    .put("type", "function")
                    .put(
                        "function",
                        JSONObject()
                            .put("name", tool.name)
                            .put("description", tool.description)
                            .put("parameters", parameters),
                    ),
            )
        }
        return array
    }

    private fun parseToolCalls(array: JSONArray?): List<ToolCall> {
        if (array == null) return emptyList()
        val calls = mutableListOf<ToolCall>()
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index) ?: continue
            val function = item.optJSONObject("function") ?: continue
            val name = function.optString("name")
            if (name.isBlank()) continue
            calls += ToolCall(
                id = item.optString("id").ifBlank { "call_$index" },
                name = name,
                argumentsJson = function.optString("arguments").ifBlank { "{}" },
            )
        }
        return calls
    }

    private fun parseUsage(root: JSONObject): UsageSnapshot? {
        val usage = root.optJSONObject("usage") ?: return null
        val promptTokens = usage.optInt("prompt_tokens", 0)
        val completionTokens = usage.optInt("completion_tokens", 0)
        val details = usage.optJSONObject("prompt_tokens_details")
        val hit = usage.optInt(
            "prompt_cache_hit_tokens",
            details?.optInt("cached_tokens", 0) ?: 0,
        )
        val miss = usage.optInt(
            "prompt_cache_miss_tokens",
            if (promptTokens > 0) (promptTokens - hit).coerceAtLeast(0) else 0,
        )
        return UsageSnapshot(
            promptTokens = promptTokens,
            completionTokens = completionTokens,
            cacheHitTokens = hit,
            cacheMissTokens = miss,
        )
    }

    private fun humanReadableError(statusCode: Int, rawBody: String): String {
        val serverMessage = runCatching {
            JSONObject(rawBody).optJSONObject("error")?.optString("message")
        }.getOrNull()?.takeIf { it.isNotBlank() }
        val hint = when (statusCode) {
            400 -> "请求参数错误"
            401 -> "API Key 无效或已过期，请到设置页检查"
            402 -> "账户余额不足"
            403 -> "无权限访问该模型"
            404 -> "接口地址错误（检查 Base URL）"
            422 -> "请求体校验失败"
            429 -> "触发限流，稍后重试"
            in 500..599 -> "DeepSeek 服务端异常（$statusCode）"
            else -> "请求失败（HTTP $statusCode）"
        }
        return if (serverMessage != null) "$hint：$serverMessage" else hint
    }

    /** 把官方 `server_tool_event` 翻译成一句给用户看的中文。 */
    private fun describeWebToolEvent(event: JSONObject): String? {
        val type = event.optString("type")
        val call = event.optJSONObject("call")
        val action = call?.optJSONObject("action")
        return when (type) {
            "call_started" -> when (action?.optString("type").orEmpty()) {
                "search" -> {
                    val queries = action?.optJSONArray("queries")
                    val list = buildList {
                        if (queries != null) {
                            for (index in 0 until queries.length()) {
                                queries.optString(index).takeIf { it.isNotBlank() }?.let { add(it) }
                            }
                        }
                    }
                    "联网搜索：${list.joinToString(" / ").ifBlank { "进行中…" }}"
                }

                "open_page" -> "打开网页：${action?.optString("url").orEmpty()}"
                "find_in_page" -> "页内查找：${action?.optString("pattern").orEmpty()}"
                "read_link" -> "阅读链接：${action?.optString("url").orEmpty()}"
                else -> "联网工具执行中…"
            }

            "call_completed" -> {
                if (call?.optString("status") == "completed") {
                    val count = call.optJSONArray("sources")?.length() ?: 0
                    if (count > 0) "联网完成，获得 $count 条来源" else "联网完成"
                } else {
                    val code = call?.optJSONObject("error")?.optString("code").orEmpty()
                    "联网调用失败${if (code.isNotBlank()) "（$code）" else ""}"
                }
            }

            else -> null
        }
    }

    /** 从 call 的 sources / page 里收集引用来源，按 URL 去重。 */
    private fun collectSources(call: JSONObject?, into: MutableMap<String, String>) {
        if (call == null) return
        val sources = call.optJSONArray("sources")
        if (sources != null) {
            for (index in 0 until sources.length()) {
                val item = sources.optJSONObject(index) ?: continue
                val url = item.optString("url")
                if (url.isNotBlank()) {
                    into.putIfAbsent(url, item.optString("title").ifBlank { url })
                }
            }
        }
        val page = call.optJSONObject("page")
        if (page != null) {
            val url = page.optString("url")
            if (url.isNotBlank()) into.putIfAbsent(url, page.optString("title").ifBlank { url })
        }
    }

    /** 流式 tool_calls 是分片下发的，需要按 index 累积 id / name / arguments。 */
    private class ToolCallAccumulator {
        private val ids = linkedMapOf<Int, String>()
        private val names = linkedMapOf<Int, String>()
        private val arguments = linkedMapOf<Int, StringBuilder>()

        fun merge(array: JSONArray) {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val slot = item.optInt("index", names.size)
                item.optString("id").takeIf { it.isNotBlank() }?.let { ids[slot] = it }
                val function = item.optJSONObject("function") ?: continue
                function.optString("name").takeIf { it.isNotBlank() }?.let { names[slot] = it }
                val partial = function.optString("arguments", "")
                if (partial.isNotEmpty()) {
                    arguments.getOrPut(slot) { StringBuilder() }.append(partial)
                }
            }
        }

        fun build(): List<ToolCall> = (names.keys + ids.keys).distinct().sorted().mapNotNull { slot ->
            val name = names[slot] ?: return@mapNotNull null
            ToolCall(
                id = ids[slot] ?: "call_$slot",
                name = name,
                argumentsJson = arguments[slot]?.toString()?.ifBlank { "{}" } ?: "{}",
            )
        }
    }

    companion object {
        private const val DATA_PREFIX = "data:"
        private const val DONE_SENTINEL = "[DONE]"

        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            // SSE 两条 chunk 之间可能隔很久，读超时给足；总超时交给调用方控制。
            .readTimeout(180, TimeUnit.SECONDS)
            .callTimeout(0, TimeUnit.MILLISECONDS)
            .retryOnConnectionFailure(false)
            .build()
    }
}
