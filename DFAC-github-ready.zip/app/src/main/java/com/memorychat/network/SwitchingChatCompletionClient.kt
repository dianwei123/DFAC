package com.memorychat.network

import com.memorychat.data.settings.AppSettings
import com.memorychat.domain.RetryPolicy
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow

/**
 * 按设置动态切换实现：填了 API Key 走真实 DeepSeek，没填则走离线 Mock。
 * 这样用户随时可以在设置页输入 Key 立即生效，不需要重启或重建依赖。
 */
class SwitchingChatCompletionClient(
    private val settingsProvider: () -> AppSettings,
    private val remote: ChatCompletionClient,
    private val mock: ChatCompletionClient,
) : ChatCompletionClient {

    override fun stream(request: ChatCompletionRequest, retryPolicy: RetryPolicy): Flow<StreamEvent> = flow {
        emitAll(active().stream(request, retryPolicy))
    }

    override suspend fun complete(request: ChatCompletionRequest): CompletionResult =
        active().complete(request)

    override suspend fun listModels(): List<String> = active().listModels()

    override fun close() {
        remote.close()
        mock.close()
    }

    private fun active(): ChatCompletionClient =
        if (settingsProvider().isMockMode) mock else remote
}
