package com.memorychat.network

import com.memorychat.domain.RetryPolicy
import com.memorychat.domain.UsageSnapshot
import com.memorychat.domain.model.ToolCall
import com.memorychat.domain.model.ToolSpec
import com.memorychat.domain.model.WireMessage
import kotlinx.coroutines.flow.Flow
import java.io.IOException

/** 组装好的一次 chat/completions 请求（字段按 DeepSeek 2026 现行文档）。 */
data class ChatCompletionRequest(
    val model: String,
    val messages: List<WireMessage>,
    val temperature: Double,
    val topP: Double? = null,
    val maxTokens: Int? = null,
    val stream: Boolean = true,
    val tools: List<ToolSpec> = emptyList(),
    /** 官方 `thinking.type`：null 表示不传（服务端按 reasoning_effort 决定，默认开启）。 */
    val thinkingEnabled: Boolean? = null,
    /** 官方 `reasoning_effort`：low / high / max，仅思考模式生效。 */
    val reasoningEffort: String? = null,
    /** 官方服务端联网搜索工具 `deepseek_web_search`（与 function 工具互斥）。 */
    val webSearchEnabled: Boolean = false,
)

/** 联网工具返回给 UI 展示的来源。 */
data class WebSource(val title: String, val url: String)

/** 流式事件。 */
sealed interface StreamEvent {
    /** 增量正文（架构图节点「逐 chunk 解析，更新最后一条气泡」）。 */
    data class Delta(val text: String) : StreamEvent

    /** 思考模式下的推理过程增量（官方 `delta.reasoning_content`）。 */
    data class Reasoning(val text: String) : StreamEvent

    /** 联网工具过程（官方 `choice.server_tool_event`）：搜索中 / 打开网页 / 完成。 */
    data class WebToolEvent(val message: String) : StreamEvent

    /** 联网工具产生的引用来源（官方 `annotations` / `server_tool_calls[].sources`）。 */
    data class Sources(val items: List<WebSource>) : StreamEvent

    /** 模型请求调用工具。 */
    data class ToolCallRequested(val calls: List<ToolCall>) : StreamEvent

    /** usage 到达（架构图节点「读取 usage 字段」）。 */
    data class UsageReported(val usage: UsageSnapshot) : StreamEvent

    /** 指数退避重试中（架构图节点「指数退避重试 最多 3 次」）。 */
    data class Retrying(
        val attempt: Int,
        val maxAttempts: Int,
        val statusCode: Int?,
        val reason: String,
    ) : StreamEvent

    data class Completed(val finishReason: String?) : StreamEvent
}

/** 非流式结果，供摘要 Worker / 连接测试使用。 */
data class CompletionResult(
    val text: String,
    val usage: UsageSnapshot? = null,
    val toolCalls: List<ToolCall> = emptyList(),
    val finishReason: String? = null,
)

/** 接口层抛出的异常：携带 HTTP 状态码，用于区分「可重试」与「不可重试」。 */
class ApiException(
    val statusCode: Int,
    override val message: String,
    cause: Throwable? = null,
) : IOException(message, cause) {
    val retryable: Boolean get() = statusCode == 429 || statusCode in 500..599
}

/**
 * 模型客户端抽象。真实实现见 [DeepSeekHttpClient]，离线实现见 [MockChatCompletionClient]。
 */
interface ChatCompletionClient {

    /**
     * 发起 SSE 流式请求。内部完成：
     * 200 → 解析 chunk；429/5xx → 指数退避重试（最多 [RetryPolicy.maxAttempts] 次）；
     * 4xx（非 429）→ [ApiException]，由上层展示错误态。
     */
    fun stream(request: ChatCompletionRequest, retryPolicy: RetryPolicy): Flow<StreamEvent>

    suspend fun complete(request: ChatCompletionRequest): CompletionResult

    /** GET /models：列出当前 Key 可用的模型（用于校正下拉选项）。 */
    suspend fun listModels(): List<String>

    fun close()
}
