package com.memorychat.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {

    @Query("SELECT * FROM messages WHERE sessionId = :sessionId ORDER BY id ASC")
    fun observe(sessionId: Long): Flow<List<MessageEntity>>

    @Query(
        "SELECT * FROM messages WHERE sessionId = :sessionId AND status = 'complete' " +
            "ORDER BY id ASC",
    )
    suspend fun listComplete(sessionId: Long): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE sessionId = :sessionId ORDER BY id ASC")
    suspend fun list(sessionId: Long): List<MessageEntity>

    @Insert
    suspend fun insert(message: MessageEntity): Long

    @Query("UPDATE messages SET content = :content, status = :status WHERE id = :id")
    suspend fun updateContent(id: Long, content: String, status: String)

    @Query(
        "UPDATE messages SET promptTokens = :promptTokens, completionTokens = :completionTokens, " +
            "cacheHitTokens = :cacheHitTokens WHERE id = :id",
    )
    suspend fun updateUsage(
        id: Long,
        promptTokens: Int,
        completionTokens: Int,
        cacheHitTokens: Int,
    )

    @Query("UPDATE messages SET status = :status, errorMessage = :errorMessage WHERE id = :id")
    suspend fun markStatus(id: Long, status: String, errorMessage: String? = null)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM messages WHERE sessionId = :sessionId")
    suspend fun deleteBySession(sessionId: Long)

    @Query("SELECT * FROM messages WHERE id = :id LIMIT 1")
    suspend fun find(id: Long): MessageEntity?

    @Query("DELETE FROM messages")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM messages WHERE sessionId = :sessionId")
    suspend fun count(sessionId: Long): Int

    /** 供本地 search_memory 工具检索。 */
    @Query(
        "SELECT * FROM messages WHERE sessionId = :sessionId AND content LIKE '%' || :query || '%' " +
            "ORDER BY id DESC LIMIT :limit",
    )
    suspend fun search(sessionId: Long, query: String, limit: Int): List<MessageEntity>

    /** 重新生成前清理末尾失败的 assistant 气泡。 */
    @Query(
        "DELETE FROM messages WHERE sessionId = :sessionId AND status = 'error' " +
            "AND id > COALESCE((SELECT MAX(id) FROM messages WHERE sessionId = :sessionId AND role = 'user'), 0)",
    )
    suspend fun deleteFailedAssistantsAfterLastUser(sessionId: Long): Int
}

@Dao
interface SessionDao {

    @Query("SELECT * FROM sessions ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<SessionEntity>>

    @Query("SELECT * FROM sessions WHERE id = :id LIMIT 1")
    suspend fun find(id: Long): SessionEntity?

    @Query("SELECT * FROM sessions ORDER BY updatedAt DESC LIMIT 1")
    suspend fun latest(): SessionEntity?

    @Insert
    suspend fun insert(session: SessionEntity): Long

    @Query("UPDATE sessions SET updatedAt = :updatedAt WHERE id = :id")
    suspend fun touch(id: Long, updatedAt: Long)

    @Query(
        "UPDATE sessions SET compressedRounds = compressedRounds + :rounds, " +
            "savedTokens = savedTokens + :savedTokens WHERE id = :id",
    )
    suspend fun bumpCompression(id: Long, rounds: Int, savedTokens: Int)

    @Query("UPDATE sessions SET cacheHitRate = :hitRate, cacheDiag = :diag WHERE id = :id")
    suspend fun updateCacheStats(id: Long, hitRate: Double, diag: String?)

    @Query("UPDATE sessions SET cacheDiag = NULL WHERE id = :id")
    suspend fun clearCacheDiag(id: Long)

    @Query("UPDATE sessions SET title = :title WHERE id = :id")
    suspend fun updateTitle(id: Long, title: String)

    @Query(
        "UPDATE sessions SET compressedRounds = 0, savedTokens = 0, cacheHitRate = 0.0, " +
            "cacheDiag = NULL WHERE id = :id",
    )
    suspend fun resetStats(id: Long)

    @Query("DELETE FROM sessions WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM sessions")
    suspend fun clearAll()
}

@Dao
interface SummaryCacheDao {

    @Query("SELECT * FROM summary_cache WHERE prefixHash = :prefixHash LIMIT 1")
    suspend fun find(prefixHash: String): SummaryCacheEntity?

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: SummaryCacheEntity)

    @Query("DELETE FROM summary_cache WHERE sessionId = :sessionId")
    suspend fun clearSession(sessionId: Long)

    @Query("DELETE FROM summary_cache")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM summary_cache")
    suspend fun count(): Int
}
