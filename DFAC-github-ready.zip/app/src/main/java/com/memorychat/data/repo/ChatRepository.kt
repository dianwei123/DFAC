package com.memorychat.data.repo

import com.memorychat.data.local.MessageDao
import com.memorychat.data.local.MessageEntity
import com.memorychat.data.local.MessageStatus
import com.memorychat.data.local.SessionDao
import com.memorychat.data.local.SessionEntity
import com.memorychat.data.local.SummaryCacheDao
import com.memorychat.data.settings.AppSettings
import com.memorychat.data.settings.SettingsRepository
import com.memorychat.domain.AssembledPrompt
import com.memorychat.domain.CacheDiagnosis
import com.memorychat.domain.LocalToolRuntime
import com.memorychat.domain.PrefixHash
import com.memorychat.domain.PromptAssembler
import com.memorychat.domain.PromptCacheInspector
import com.memorychat.domain.RetryPolicy
import com.memorychat.domain.TokenEstimator
import com.memorychat.domain.ToolCatalog
import com.memorychat.domain.UsageSnapshot
import com.memorychat.domain.model.ChatMessage
import com.memorychat.domain.model.Role
import com.memorychat.domain.model.ToolCall
import com.memorychat.domain.model.WireMessage
import com.memorychat.network.ApiException
import com.memorychat.network.ChatCompletionClient
import com.memorychat.network.ChatCompletionRequest
import com.memorychat.network.StreamEvent
import com.memorychat.network.WebSource
import com.memorychat.work.SummaryScheduler
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.IOException

/** 一轮对话的当前阶段，供 UI 显示状态条。 */
enum class TurnPhase {
    ESTIMATING,
    COMPRESSING,
    SUMMARY_READY,
    DEGRADED,
    REQUESTING,
    RETRYING,
    REASONING,
    WEB_TOOL,
    CACHE_CHECK,
    DONE,
}

/** 连接测试结果：可用模型列表 + 实际使用的模型 + 模型回复。 */
data class ProbeResult(
    val availableModels: List<String>,
    val activeModel: String,
    val reply: String,
    val autoSwitched: Boolean,
)

data class TurnStatus(
    val phase: TurnPhase,
    val message: String,
    val compressedRounds: Int = 0,
    val savedTokens: Int = 0,
    val cacheHitRate: Double? = null,
    val degraded: Boolean = false,
    val contextTokens: Int = 0,
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
)

/** 仓库层向 UI 推送的流式回调。 */
interface TurnSink {
    suspend fun onAssistantCreated(messageId: Long) = Unit

    suspend fun onAssistantText(messageId: Long, fullText: String) = Unit

    suspend fun onStatus(status: TurnStatus) = Unit

    suspend fun onError(message: String, retryable: Boolean) = Unit
}

/**
 * 链路编排器：把架构图里的每一步按顺序串起来。
 *
 * 用户输入消息
 *  → 写入 Room messages
 *  → 估算历史 token
 *  → 超阈值则压缩（前缀 hash → summary_cache 命中/未命中 → WorkManager 生成/超时 fail-open）
 *  → 组装请求（system + 摘要 + 最近 N 轮原文 + 末条 user 压缩指令）
 *  → 注入配置（temperature / 人设 / 工具参数）
 *  → OkHttp SSE（200 逐 chunk 更新气泡；429/5xx 指数退避；4xx 直接报错）
 *  → 流结束写完整回复 + 读 usage
 *  → prompt_cache_hit_tokens 命中率体检（偏低则标记会话并检查前缀动态内容）
 *  → 更新压缩状态条（已压缩 X 轮 / 节省 Y tokens）
 */
class ChatRepository(
    private val messageDao: MessageDao,
    private val sessionDao: SessionDao,
    private val summaryCacheDao: SummaryCacheDao,
    private val settingsRepository: SettingsRepository,
    private val tokenEstimator: TokenEstimator,
    private val chatClient: ChatCompletionClient,
    private val summaryScheduler: SummaryScheduler,
    private val toolRuntimeProvider: (sessionId: Long) -> LocalToolRuntime,
) {

    fun observeMessages(sessionId: Long): Flow<List<MessageEntity>> = messageDao.observe(sessionId)

    /** 历史对话列表（侧边栏用），按最近更新时间倒序。 */
    fun observeSessions(): Flow<List<SessionEntity>> = sessionDao.observeAll()

    suspend fun deleteSession(sessionId: Long) {
        messageDao.deleteBySession(sessionId)
        summaryCacheDao.clearSession(sessionId)
        sessionDao.delete(sessionId)
    }

    suspend fun ensureSession(): Long = sessionDao.latest()?.id ?: createSession()

    suspend fun createSession(): Long {
        val now = System.currentTimeMillis()
        return sessionDao.insert(
            SessionEntity(title = DEFAULT_TITLE, createdAt = now, updatedAt = now),
        )
    }

    suspend fun sessionSnapshot(sessionId: Long): SessionEntity? = sessionDao.find(sessionId)

    suspend fun clearSession(sessionId: Long) {
        messageDao.deleteBySession(sessionId)
        summaryCacheDao.clearSession(sessionId)
        sessionDao.resetStats(sessionId)
        sessionDao.updateTitle(sessionId, DEFAULT_TITLE)
        sessionDao.touch(sessionId, System.currentTimeMillis())
    }

    /** 用户发送一条消息：先落库，再走完整链路。 */
    suspend fun send(sessionId: Long, rawText: String, sink: TurnSink) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        val settings = settingsRepository.snapshot()
        val now = System.currentTimeMillis()
        val existingCount = messageDao.count(sessionId)
        messageDao.insert(
            MessageEntity(
                sessionId = sessionId,
                role = ROLE_USER,
                content = text,
                status = MessageStatus.COMPLETE,
                createdAt = now,
            ),
        )
        if (existingCount == 0) {
            sessionDao.updateTitle(sessionId, text.take(TITLE_MAX_LENGTH))
        }
        sessionDao.touch(sessionId, now)
        completeTurn(sessionId, settings, sink)
    }

    /** 「保留用户消息可重发」：清掉末尾失败的 assistant 气泡后重新走一遍链路。 */
    suspend fun regenerate(sessionId: Long, sink: TurnSink) {
        messageDao.deleteFailedAssistantsAfterLastUser(sessionId)
        val settings = settingsRepository.snapshot()
        completeTurn(sessionId, settings, sink)
    }

    /** 当前会话的上下文 token 估算（供 UI 的 token 消耗组件常显）。 */
    suspend fun estimateContextTokens(sessionId: Long): Int =
        tokenEstimator.estimate(
            messageDao.listComplete(sessionId)
                .filter { it.role == ROLE_USER || it.role == ROLE_ASSISTANT }
                .map { it.toDomain() },
        )

    /**
     * 连接测试（官方 `GET /models` + 一次极小的非流式 chat 请求）。
     *
     * 会先用 `/models` 校验当前模型是否可用：不可用就自动切到第一个可用模型并保存，
     * 避免用户拿 deepseek-chat 这种已下线的模型名一直 400。
     */
    suspend fun probeConnection(): ProbeResult = withContext(Dispatchers.IO) {
        val settings = settingsRepository.snapshot()
        require(settings.llmEnabled) { "LLM 调用总开关已关闭，先打开再测试连接" }

        val models = runCatching { chatClient.listModels() }.getOrElse { emptyList() }
        if (models.isNotEmpty()) {
            // 持久化真实可用模型：抽屉里的模型下拉直接用这份列表
            settingsRepository.saveAvailableModels(models)
        }
        var activeModel = settings.model
        var autoSwitched = false
        if (models.isNotEmpty() && activeModel !in models) {
            activeModel = models.first()
            settingsRepository.save(settings.copy(model = activeModel))
            autoSwitched = true
        }

        val result = chatClient.complete(
            ChatCompletionRequest(
                model = activeModel,
                messages = listOf(WireMessage(Role.USER, "只回复两个字母：ok")),
                temperature = 0.0,
                maxTokens = 16,
                stream = false,
                thinkingEnabled = false,
            ),
        )
        ProbeResult(
            availableModels = models.ifEmpty { AppSettings.OFFICIAL_MODELS },
            activeModel = activeModel,
            reply = result.text.ifBlank { "（连接成功，但模型返回空内容）" },
            autoSwitched = autoSwitched,
        )
    }

    // ------------------------------------------------------------------ 主链路

    private suspend fun completeTurn(
        sessionId: Long,
        settings: AppSettings,
        sink: TurnSink,
    ) {
        val history = messageDao.listComplete(sessionId)
            .filter { it.role == ROLE_USER || it.role == ROLE_ASSISTANT }
            .map { it.toDomain() }
        if (history.isEmpty()) return

        val assembler = PromptAssembler(recentRounds = settings.recentRounds)
        val estimatedTokens = tokenEstimator.estimate(history)
        sink.onStatus(
            TurnStatus(
                TurnPhase.ESTIMATING,
                "估算历史 $estimatedTokens tokens（阈值 ${settings.tokenThreshold}）",
                contextTokens = estimatedTokens,
            ),
        )

        // LLM 总开关关闭：只落库、给本地提示，绝不发请求。
        if (!settings.llmEnabled) {
            completeOfflineTurn(sessionId, estimatedTokens, sink)
            return
        }

        var degraded = false
        val assembled: AssembledPrompt = if (estimatedTokens <= settings.tokenThreshold) {
            assembler.assemble(history, summary = null)
        } else {
            sink.onStatus(TurnStatus(TurnPhase.COMPRESSING, "超过阈值，触发压缩流程"))
            val split = assembler.split(history)
            if (!split.hasCompressible) {
                assembler.assemble(history, summary = null)
            } else {
                val prefixHash = PrefixHash.of(split.compressible)
                val cached = summaryCacheDao.find(prefixHash)
                val summary: String? = if (cached != null) {
                    sink.onStatus(
                        TurnStatus(TurnPhase.SUMMARY_READY, "summary_cache 命中（${prefixHash.take(8)}…），读取冻结摘要"),
                    )
                    cached.summary
                } else {
                    sink.onStatus(
                        TurnStatus(TurnPhase.COMPRESSING, "summary_cache 未命中（${prefixHash.take(8)}…），提交 WorkManager 异步生成"),
                    )
                    val generated = summaryScheduler.scheduleAndAwait(
                        sessionId = sessionId,
                        prefixHash = prefixHash,
                        coveredMessages = split.compressible.size,
                        timeoutMs = settings.summaryTimeoutMs + SUMMARY_WAIT_GRACE_MS,
                    )
                    val written = summaryCacheDao.find(prefixHash)
                    if (generated && written != null) {
                        sink.onStatus(TurnStatus(TurnPhase.SUMMARY_READY, "摘要生成完成，已冻结写入 summary_cache"))
                        written.summary
                    } else {
                        degraded = true
                        sink.onStatus(
                            TurnStatus(
                                TurnPhase.DEGRADED,
                                "摘要生成失败或超时，降级为原文转发（fail-open）",
                                degraded = true,
                            ),
                        )
                        null
                    }
                }
                assembler.assemble(history, summary)
            }
        }

        // 联网搜索是官方服务端工具，与 function 工具互斥；开启时只用服务端工具
        val functionTools = if (settings.toolsEnabled && !settings.webSearchEnabled) {
            ToolCatalog.ALL
        } else {
            emptyList()
        }
        // 官方要求联网工具使用 deepseek-flash 模型
        val requestModel = if (settings.webSearchEnabled) {
            AppSettings.OFFICIAL_MODELS.first()
        } else {
            settings.model
        }
        val conversation = mutableListOf<WireMessage>()
        conversation += WireMessage(Role.SYSTEM, assembled.systemPrompt)
        assembled.messages.forEach { conversation += WireMessage.of(it) }

        val assistantId = messageDao.insert(
            MessageEntity(
                sessionId = sessionId,
                role = ROLE_ASSISTANT,
                content = "",
                status = MessageStatus.STREAMING,
                createdAt = System.currentTimeMillis(),
            ),
        )
        sink.onAssistantCreated(assistantId)

        val retryPolicy = RetryPolicy(maxAttempts = settings.maxRetries)
        val finalText = StringBuilder()
        var lastUsage: UsageSnapshot? = null
        var lastPersistAt = 0L
        var reasoningChars = 0
        var lastReasoningStatusAt = 0L
        var webSources: List<WebSource> = emptyList()

        try {
            var round = 0
            while (true) {
                round++
                val roundText = StringBuilder()
                var toolCalls: List<ToolCall> = emptyList()
                var roundUsage: UsageSnapshot? = null

                val request = ChatCompletionRequest(
                    model = requestModel,
                    messages = conversation.toList(),
                    // 架构图节点「注入配置: temperature=1.3 / 活人感 System Prompt / 全家桶工具参数」
                    temperature = settings.temperature,
                    topP = settings.topP,
                    // 思考模式会消耗大量输出 token，官方默认 64K；这里给一个安全下限
                    maxTokens = if (settings.thinkingEnabled) {
                        maxOf(settings.maxTokens, THINKING_MIN_MAX_TOKENS)
                    } else {
                        settings.maxTokens
                    },
                    stream = true,
                    tools = functionTools,
                    thinkingEnabled = settings.thinkingEnabled,
                    reasoningEffort = settings.reasoningEffort,
                    // 联网搜索：官方服务端工具 deepseek_web_search
                    webSearchEnabled = settings.webSearchEnabled,
                )
                if (round == 1) {
                    sink.onStatus(
                        TurnStatus(TurnPhase.REQUESTING, "OkHttp 发起 SSE 请求：${settings.endpoint}"),
                    )
                }

                chatClient.stream(request, retryPolicy).collect { event ->
                    when (event) {
                        is StreamEvent.Delta -> {
                            roundText.append(event.text)
                            finalText.append(event.text)
                            sink.onAssistantText(assistantId, finalText.toString())
                            val now = System.currentTimeMillis()
                            if (now - lastPersistAt >= PERSIST_INTERVAL_MS) {
                                lastPersistAt = now
                                messageDao.updateContent(
                                    assistantId,
                                    finalText.toString(),
                                    MessageStatus.STREAMING,
                                )
                            }
                        }

                        is StreamEvent.UsageReported -> roundUsage = event.usage

                        is StreamEvent.Reasoning -> {
                            // 思考模式的推理内容不进气泡，只在状态条上显示进度
                            reasoningChars += event.text.length
                            val now = System.currentTimeMillis()
                            if (now - lastReasoningStatusAt >= REASONING_STATUS_INTERVAL_MS) {
                                lastReasoningStatusAt = now
                                sink.onStatus(
                                    TurnStatus(
                                        TurnPhase.REASONING,
                                        "思考中… 已生成 $reasoningChars 字推理",
                                    ),
                                )
                            }
                        }

                        is StreamEvent.ToolCallRequested -> toolCalls = event.calls

                        is StreamEvent.WebToolEvent -> sink.onStatus(
                            TurnStatus(TurnPhase.WEB_TOOL, event.message),
                        )

                        is StreamEvent.Sources -> webSources = event.items

                        is StreamEvent.Retrying -> sink.onStatus(
                            TurnStatus(
                                TurnPhase.RETRYING,
                                "HTTP ${event.statusCode ?: "IO"}，指数退避后重试（第 ${event.attempt + 1}/${event.maxAttempts} 次）：${event.reason}",
                            ),
                        )

                        is StreamEvent.Completed -> Unit
                    }
                }
                roundUsage?.let { lastUsage = it }

                val needToolRound = toolCalls.isNotEmpty() &&
                    functionTools.isNotEmpty() &&
                    round <= settings.maxToolRounds
                if (!needToolRound) break

                // 工具调用：把模型的 tool_calls 和本地执行结果回灌，再请求一轮。
                conversation += WireMessage(Role.ASSISTANT, roundText.toString(), toolCalls)
                val runtime = toolRuntimeProvider(sessionId)
                for (call in toolCalls) {
                    val result = runCatching { runtime.execute(call.name, call.argumentsJson) }
                        .getOrElse { """{"error":"${it.message.orEmpty()}"}""" }
                    conversation += WireMessage(Role.TOOL, result, toolCallId = call.id)
                }
                if (finalText.isNotEmpty()) finalText.append("\n\n")
            }

            if (finalText.isBlank()) {
                val detail = if (reasoningChars > 0) {
                    "模型只产出了思考内容（思考模式），正文为空。请调大 max_tokens 或关闭思考模式"
                } else {
                    "模型返回了空内容"
                }
                messageDao.updateContent(assistantId, "", MessageStatus.ERROR)
                messageDao.markStatus(assistantId, MessageStatus.ERROR, detail)
                sink.onError("$detail，可以点重发", retryable = true)
                return
            }

            messageDao.updateContent(assistantId, finalText.toString(), MessageStatus.COMPLETE)
            lastUsage?.let { usage ->
                messageDao.updateUsage(
                    assistantId,
                    usage.promptTokens,
                    usage.completionTokens,
                    usage.cacheHitTokens,
                )
            }

            // 压缩状态条：已压缩 X 轮 / 节省 Y tokens
            if (assembled.compressed) {
                val compressibleTokens = tokenEstimator.estimate(assembled.compressible)
                val summaryTokens = tokenEstimator.estimate(assembled.summary.orEmpty())
                val savedTokens = (compressibleTokens - summaryTokens).coerceAtLeast(0)
                val rounds = assembled.compressible.count { it.role == Role.USER }
                sessionDao.bumpCompression(sessionId, rounds, savedTokens)
            }

            // 缓存体检
            val diagnosis = lastUsage?.takeIf { it.hasUsage }?.let { usage ->
                PromptCacheInspector(settings.cacheHitFloor).diagnose(usage, assembled.staticPrefix())
            }
            applyDiagnosis(sessionId, diagnosis, sink)

            sessionDao.touch(sessionId, System.currentTimeMillis())
            val session = sessionDao.find(sessionId)
            val statusText = buildString {
                append("已压缩 ${session?.compressedRounds ?: 0} 轮 · 节省 ${session?.savedTokens ?: 0} tokens")
                diagnosis?.let { append(" · 缓存命中 ${(it.hitRate * 100).toInt()}%") }
                if (webSources.isNotEmpty()) {
                    append(" · 联网来源 ${webSources.size} 条")
                }
                if (degraded) append(" · 本轮 fail-open")
            }
            if (webSources.isNotEmpty()) {
                // 把来源标题并入状态文案，用户能一眼看到查了哪些站点
                val titles = webSources.take(2).joinToString("、") { it.title.take(24) }
                sink.onStatus(
                    TurnStatus(
                        TurnPhase.WEB_TOOL,
                        "联网来源：$titles${if (webSources.size > 2) " 等 ${webSources.size} 条" else ""}",
                    ),
                )
            }
            sink.onStatus(
                TurnStatus(
                    phase = TurnPhase.DONE,
                    message = statusText,
                    compressedRounds = session?.compressedRounds ?: 0,
                    savedTokens = session?.savedTokens ?: 0,
                    cacheHitRate = session?.cacheHitRate,
                    degraded = degraded,
                    contextTokens = estimatedTokens,
                    promptTokens = lastUsage?.promptTokens ?: 0,
                    completionTokens = lastUsage?.completionTokens ?: 0,
                ),
            )
        } catch (e: CancellationException) {
            messageDao.updateContent(assistantId, finalText.toString(), MessageStatus.ERROR)
            messageDao.markStatus(assistantId, MessageStatus.ERROR, "已取消")
            throw e
        } catch (e: ApiException) {
            failTurn(assistantId, finalText, e.message, e.retryable, sink)
        } catch (e: IOException) {
            failTurn(assistantId, finalText, "网络异常：${e.message.orEmpty()}", true, sink)
        } catch (e: Exception) {
            failTurn(
                assistantId,
                finalText,
                e.message ?: "请求失败（${e.javaClass.simpleName}）",
                retryable = false,
                sink = sink,
            )
        }
    }

    /**
     * LLM 总开关关闭时的一轮：消息已经落库，这里只插入一条本地提示消息，
     * 不发起任何网络请求、也不触发摘要 Worker。
     */
    private suspend fun completeOfflineTurn(
        sessionId: Long,
        contextTokens: Int,
        sink: TurnSink,
    ) {
        val assistantId = messageDao.insert(
            MessageEntity(
                sessionId = sessionId,
                role = ROLE_ASSISTANT,
                content = "（LLM 已手动关闭）这条消息已保存，本轮没有调用 DeepSeek。" +
                    "从屏幕右侧滑出侧边栏，打开「LLM 调用总开关」后就能继续对话。",
                status = MessageStatus.COMPLETE,
                createdAt = System.currentTimeMillis(),
            ),
        )
        sink.onAssistantCreated(assistantId)
        sessionDao.touch(sessionId, System.currentTimeMillis())
        val session = sessionDao.find(sessionId)
        sink.onStatus(
            TurnStatus(
                phase = TurnPhase.DONE,
                message = "LLM 已关闭 · 本轮未请求接口 · 上下文 $contextTokens tok",
                compressedRounds = session?.compressedRounds ?: 0,
                savedTokens = session?.savedTokens ?: 0,
                cacheHitRate = session?.cacheHitRate,
                contextTokens = contextTokens,
            ),
        )
    }

    private suspend fun applyDiagnosis(
        sessionId: Long,
        diagnosis: CacheDiagnosis?,
        sink: TurnSink,
    ) {
        if (diagnosis == null) return
        if (diagnosis.healthy) {
            sessionDao.updateCacheStats(sessionId, diagnosis.hitRate, null)
        } else {
            // 架构图节点「标记该会话 + 检查 system/前缀是否含动态内容」
            sessionDao.updateCacheStats(sessionId, diagnosis.hitRate, diagnosis.summary)
            sink.onStatus(TurnStatus(TurnPhase.CACHE_CHECK, diagnosis.summary))
        }
    }

    private suspend fun failTurn(
        assistantId: Long,
        partial: StringBuilder,
        message: String,
        retryable: Boolean,
        sink: TurnSink,
    ) {
        // 保留已生成的部分内容，并明确标记错误；用户消息保持完整，所以可以直接重发。
        messageDao.updateContent(assistantId, partial.toString(), MessageStatus.ERROR)
        messageDao.markStatus(assistantId, MessageStatus.ERROR, message)
        sink.onError(message, retryable)
    }

    private fun MessageEntity.toDomain(): ChatMessage = ChatMessage(
        id = id,
        role = Role.fromWire(role),
        content = content,
        createdAt = createdAt,
    )

    companion object {
        private const val ROLE_USER = "user"
        private const val ROLE_ASSISTANT = "assistant"
        private const val DEFAULT_TITLE = "新的对话"
        private const val TITLE_MAX_LENGTH = 18
        private const val PERSIST_INTERVAL_MS = 350L
        private const val SUMMARY_WAIT_GRACE_MS = 3_000L
        private const val THINKING_MIN_MAX_TOKENS = 8_192
        private const val REASONING_STATUS_INTERVAL_MS = 600L
    }
}
