package com.memorychat.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** 消息状态：complete 已落库完整；streaming 正在流式接收；error 请求失败但保留可重发。 */
object MessageStatus {
    const val COMPLETE = "complete"
    const val STREAMING = "streaming"
    const val ERROR = "error"
}

/** 会话里的一条消息，对应架构图节点「写入 Room: messages 表」。 */
@Entity(
    tableName = "messages",
    indices = [Index("sessionId"), Index("createdAt")],
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val sessionId: Long,
    val role: String,
    val content: String,
    val status: String = MessageStatus.COMPLETE,
    val createdAt: Long,
    val errorMessage: String? = null,
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
    val cacheHitTokens: Int = 0,
)

/** 会话级统计，用来渲染「已压缩 X 轮 / 节省 Y tokens」状态条。 */
@Entity(tableName = "sessions")
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val compressedRounds: Int = 0,
    val savedTokens: Int = 0,
    val cacheHitRate: Double = 0.0,
    val cacheDiag: String? = null,
)

/**
 * 摘要缓存（架构图节点「summary_cache 中已有该 hash?」/「写入 summary_cache 冻结摘要」）。
 * 主键是历史前缀 hash：同一段历史只会被压缩一次，摘要一旦冻结就不再改写。
 */
@Entity(tableName = "summary_cache")
data class SummaryCacheEntity(
    @PrimaryKey val prefixHash: String,
    val sessionId: Long,
    val summary: String,
    val coveredMessages: Int,
    val createdAt: Long,
    val frozenAt: Long? = null,
)
