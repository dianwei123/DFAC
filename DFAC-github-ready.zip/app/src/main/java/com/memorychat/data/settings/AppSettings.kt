package com.memorychat.data.settings

/**
 * 全部可调参数。默认值即「开箱可用」的演示参数（依据 DeepSeek 官方 2026 现行文档）：
 * - 模型：`deepseek-flash`（另有 `deepseek-v4-pro`），旧的 deepseek-chat/reasoner 已下线
 * - temperature = 1.3（仅非思考模式生效；思考模式会被忽略）
 * - thinking = false：聊天默认关思考，响应快且 temperature 生效
 * - tokenThreshold = 16000，超过就触发压缩
 * - maxTokens = 4096（官方上限 384K）
 */
data class AppSettings(
    val apiKey: String = "",
    val baseUrl: String = "https://api.deepseek.com",
    val model: String = "deepseek-flash",
    val tokenThreshold: Int = 16_000,
    val recentRounds: Int = 3,
    val temperature: Double = 1.3,
    val topP: Double = 0.95,
    val maxTokens: Int = 4_096,
    val cacheHitFloor: Double = 0.30,
    val summaryTimeoutMs: Long = 20_000L,
    val maxRetries: Int = 3,
    val toolsEnabled: Boolean = false,
    val maxToolRounds: Int = 1,
    /** LLM 调用总开关：关闭后只落库，不发请求、不触发摘要任务。 */
    val llmEnabled: Boolean = true,
    /** 思考模式（官方 `thinking.type`）。关闭 = 快；开启 = 慢但更深，且 temperature 失效。 */
    val thinkingEnabled: Boolean = false,
    /** 思考强度（官方 `reasoning_effort`）：low / high / max，仅思考模式生效。 */
    val reasoningEffort: String = "high",
    /**
     * 联网搜索（官方服务端工具 `deepseek_web_search`）。
     * 声明后由模型自行决定是否搜索，搜索在服务端完成；官方要求使用 `deepseek-flash`。
     */
    val webSearchEnabled: Boolean = false,
) {
    /** 没填 Key 时自动降级为离线 Mock，方便验证整条链路。 */
    val isMockMode: Boolean get() = apiKey.isBlank()

    /** 是否真的会调用模型：总开关开着且处于在线模式。 */
    val usesRemoteModel: Boolean get() = llmEnabled && !isMockMode

    val endpoint: String
        get() {
            val root = apiRoot()
            return "$root/chat/completions"
        }

    /** GET /models：列出当前 Key 可用的模型（官方接口）。 */
    val modelsEndpoint: String get() = "${apiRoot()}/models"

    private fun apiRoot(): String {
        val normalized = baseUrl.trim().trimEnd('/')
        return when {
            normalized.isEmpty() -> "https://api.deepseek.com"
            normalized.endsWith("/chat/completions") -> normalized.removeSuffix("/chat/completions")
            normalized.endsWith("/models") -> normalized.removeSuffix("/models")
            else -> normalized
        }
    }

    companion object {
        /** 官方当前可用模型（2026 现行文档）。 */
        val OFFICIAL_MODELS = listOf("deepseek-flash", "deepseek-v4-pro")

        val OFFICIAL_EFFORT_LEVELS = listOf("low", "high", "max")

        const val KEY_API_KEY = "api_key"
        const val KEY_BASE_URL = "base_url"
        const val KEY_MODEL = "model"
        const val KEY_TOKEN_THRESHOLD = "token_threshold"
        const val KEY_RECENT_ROUNDS = "recent_rounds"
        const val KEY_TEMPERATURE = "temperature"
        const val KEY_TOP_P = "top_p"
        const val KEY_MAX_TOKENS = "max_tokens"
        const val KEY_CACHE_FLOOR = "cache_floor"
        const val KEY_SUMMARY_TIMEOUT = "summary_timeout"
        const val KEY_MAX_RETRIES = "max_retries"
        const val KEY_TOOLS_ENABLED = "tools_enabled"
        const val KEY_LLM_ENABLED = "llm_enabled"
        const val KEY_THINKING_ENABLED = "thinking_enabled"
        const val KEY_REASONING_EFFORT = "reasoning_effort"
        const val KEY_WEB_SEARCH_ENABLED = "web_search_enabled"
        const val KEY_SETTINGS_VERSION = "settings_version"
    }
}
