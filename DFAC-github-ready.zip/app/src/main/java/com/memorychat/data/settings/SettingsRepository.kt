package com.memorychat.data.settings

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate

/**
 * 设置读写。API Key 保存在应用私有 SharedPreferences 里（MODE_PRIVATE，其他应用不可读）；
 * 未接入 EncryptedSharedPreferences 是为了不额外引入依赖，README 里写明了这一点和升级建议。
 */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    init {
        migrateLegacyDefaults()
    }

    /**
     * 一次性设置迁移：
     * - v2：把老版本偏小的 max_tokens(2048) / 压缩阈值(8000) 抬到新默认；
     * - v3：默认模型从 deepseek-chat 改为 deepseek-flash；
     * - v4：按 2026 官方文档校验模型 ID，deepseek-chat / deepseek-reasoner 等已下线，
     *       统一纠正为 deepseek-flash（保留 deepseek-v4-pro）。
     */
    private fun migrateLegacyDefaults() {
        val version = prefs.getInt(AppSettings.KEY_SETTINGS_VERSION, 0)
        if (version >= SETTINGS_VERSION) return
        val editor = prefs.edit()
        if (version < 2) {
            val oldMaxTokens = prefs.getInt(AppSettings.KEY_MAX_TOKENS, 2_048)
            val oldThreshold = prefs.getInt(AppSettings.KEY_TOKEN_THRESHOLD, 8_000)
            editor.putInt(
                AppSettings.KEY_MAX_TOKENS,
                maxOf(oldMaxTokens, AppSettings().maxTokens),
            )
            editor.putInt(
                AppSettings.KEY_TOKEN_THRESHOLD,
                maxOf(oldThreshold, AppSettings().tokenThreshold),
            )
        }
        if (version < 3) {
            val storedModel = prefs.getString(AppSettings.KEY_MODEL, LEGACY_MODEL)
            if (storedModel.isNullOrBlank() || storedModel == LEGACY_MODEL) {
                editor.putString(AppSettings.KEY_MODEL, AppSettings().model)
            }
        }
        if (version < 4) {
            val storedModel = prefs.getString(AppSettings.KEY_MODEL, null)
            if (storedModel.isNullOrBlank() || storedModel !in AppSettings.OFFICIAL_MODELS) {
                editor.putString(AppSettings.KEY_MODEL, AppSettings().model)
            }
        }
        editor.putInt(AppSettings.KEY_SETTINGS_VERSION, SETTINGS_VERSION).apply()
    }

    fun snapshot(): AppSettings {
        val defaults = AppSettings()
        return AppSettings(
            apiKey = prefs.getString(AppSettings.KEY_API_KEY, "").orEmpty().trim(),
            baseUrl = prefs.getString(AppSettings.KEY_BASE_URL, defaults.baseUrl) ?: defaults.baseUrl,
            model = prefs.getString(AppSettings.KEY_MODEL, defaults.model) ?: defaults.model,            tokenThreshold = prefs.getInt(AppSettings.KEY_TOKEN_THRESHOLD, defaults.tokenThreshold),
            recentRounds = prefs.getInt(AppSettings.KEY_RECENT_ROUNDS, defaults.recentRounds),
            temperature = prefs.getFloat(
                AppSettings.KEY_TEMPERATURE,
                defaults.temperature.toFloat(),
            ).toDouble(),
            topP = prefs.getFloat(AppSettings.KEY_TOP_P, defaults.topP.toFloat()).toDouble(),
            maxTokens = prefs.getInt(AppSettings.KEY_MAX_TOKENS, defaults.maxTokens),
            cacheHitFloor = prefs.getFloat(
                AppSettings.KEY_CACHE_FLOOR,
                defaults.cacheHitFloor.toFloat(),
            ).toDouble(),
            summaryTimeoutMs = prefs.getLong(
                AppSettings.KEY_SUMMARY_TIMEOUT,
                defaults.summaryTimeoutMs,
            ),
            maxRetries = prefs.getInt(AppSettings.KEY_MAX_RETRIES, defaults.maxRetries),
            toolsEnabled = prefs.getBoolean(
                AppSettings.KEY_TOOLS_ENABLED,
                defaults.toolsEnabled,
            ),
            llmEnabled = prefs.getBoolean(
                AppSettings.KEY_LLM_ENABLED,
                defaults.llmEnabled,
            ),
            thinkingEnabled = prefs.getBoolean(
                AppSettings.KEY_THINKING_ENABLED,
                defaults.thinkingEnabled,
            ),
            reasoningEffort = prefs.getString(
                AppSettings.KEY_REASONING_EFFORT,
                defaults.reasoningEffort,
            ) ?: defaults.reasoningEffort,
            webSearchEnabled = prefs.getBoolean(
                AppSettings.KEY_WEB_SEARCH_ENABLED,
                defaults.webSearchEnabled,
            ),
        )
    }

    fun flow(): Flow<AppSettings> = callbackFlow {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            trySend(snapshot())
        }
        trySend(snapshot())
        prefs.registerOnSharedPreferenceChangeListener(listener)
        awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }.conflate()

    fun save(settings: AppSettings) {
        prefs.edit()
            .putString(AppSettings.KEY_API_KEY, settings.apiKey.trim())
            .putString(AppSettings.KEY_BASE_URL, settings.baseUrl.trim())
            .putString(AppSettings.KEY_MODEL, settings.model.trim())
            .putInt(AppSettings.KEY_TOKEN_THRESHOLD, settings.tokenThreshold)
            .putInt(AppSettings.KEY_RECENT_ROUNDS, settings.recentRounds)
            .putFloat(AppSettings.KEY_TEMPERATURE, settings.temperature.toFloat())
            .putFloat(AppSettings.KEY_TOP_P, settings.topP.toFloat())
            .putInt(AppSettings.KEY_MAX_TOKENS, settings.maxTokens)
            .putFloat(AppSettings.KEY_CACHE_FLOOR, settings.cacheHitFloor.toFloat())
            .putLong(AppSettings.KEY_SUMMARY_TIMEOUT, settings.summaryTimeoutMs)
            .putInt(AppSettings.KEY_MAX_RETRIES, settings.maxRetries)
            .putBoolean(AppSettings.KEY_TOOLS_ENABLED, settings.toolsEnabled)
            .putBoolean(AppSettings.KEY_LLM_ENABLED, settings.llmEnabled)
            .putBoolean(AppSettings.KEY_THINKING_ENABLED, settings.thinkingEnabled)
            .putString(AppSettings.KEY_REASONING_EFFORT, settings.reasoningEffort)
            .putBoolean(AppSettings.KEY_WEB_SEARCH_ENABLED, settings.webSearchEnabled)
            .apply()
    }

    fun clearApiKey() {
        prefs.edit().remove(AppSettings.KEY_API_KEY).apply()
    }

    /** 最近一次 GET /models 拿到的可用模型（持久化，体验接近「选择」而不是「手输」）。 */
    fun availableModels(): List<String> =
        prefs.getString(KEY_AVAILABLE_MODELS, "")
            .orEmpty()
            .split(',')
            .map { it.trim() }
            .filter { it.isNotBlank() }

    fun saveAvailableModels(models: List<String>) {
        prefs.edit()
            .putString(KEY_AVAILABLE_MODELS, models.distinct().joinToString(","))
            .apply()
    }

    fun maskedApiKey(): String {
        val key = snapshot().apiKey
        if (key.isBlank()) return ""
        return if (key.length <= 10) "已配置" else "${key.take(6)}…${key.takeLast(4)}"
    }

    companion object {
        private const val PREFS_NAME = "memory_chat_settings"
        private const val SETTINGS_VERSION = 4
        private const val LEGACY_MODEL = "deepseek-chat"
        private const val KEY_AVAILABLE_MODELS = "available_models"
    }
}
