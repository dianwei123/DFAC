package com.memorychat

import android.app.Application
import com.memorychat.di.ServiceLocator

/**
 * DFAC（DeepSeek Full-stack AI Client）Application 入口。
 * 只做一件事：初始化依赖容器。
 */
class DfacApp : Application() {

    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
    }
}
