package com.memorychat.work

import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.TimeoutCancellationException

/**
 * 摘要任务调度器（架构图节点「提交 WorkManager 异步生成摘要」与「否/超时 → 降级：原文转发 fail-open」）。
 *
 * 调用方最多等待 [timeoutMs]：等到了就用摘要，等不到就降级；后台任务不会被取消，
 * 生成完仍会写入 summary_cache，下一次请求就能直接命中。
 *
 * [workManagerProvider] 用惰性提供者，避免应用启动阶段就去初始化 WorkManager。
 */
class SummaryScheduler(private val workManagerProvider: () -> WorkManager) {

    suspend fun scheduleAndAwait(
        sessionId: Long,
        prefixHash: String,
        coveredMessages: Int,
        timeoutMs: Long,
    ): Boolean {
        val workName = uniqueName(sessionId, prefixHash)
        val request = OneTimeWorkRequestBuilder<SummaryWorker>()
            .setInputData(
                workDataOf(
                    SummaryWorker.KEY_SESSION_ID to sessionId,
                    SummaryWorker.KEY_PREFIX_HASH to prefixHash,
                ),
            )
            .addTag(TAG_SUMMARY)
            .build()

        return try {
            withTimeout(timeoutMs) {
                val workManager = workManagerProvider()
                workManager.enqueueUniqueWork(workName, ExistingWorkPolicy.KEEP, request)
                val infos = workManager.getWorkInfosForUniqueWorkFlow(workName)
                    .first { list -> list.any { it.state.isFinished } }
                infos.any { it.state == WorkInfo.State.SUCCEEDED }
            }
        } catch (e: TimeoutCancellationException) {
            // 超时：不取消后台任务，只是本轮降级为原文转发。
            false
        }
    }

    fun uniqueName(sessionId: Long, prefixHash: String): String =
        "$TAG_SUMMARY:$sessionId:${prefixHash.take(16)}"

    companion object {
        private const val TAG_SUMMARY = "history_summary"
    }
}
