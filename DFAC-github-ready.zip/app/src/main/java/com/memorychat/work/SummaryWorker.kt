package com.memorychat.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.memorychat.data.local.SummaryCacheEntity
import com.memorychat.di.ServiceLocator
import com.memorychat.domain.PrefixHash
import com.memorychat.domain.PromptAssembler
import com.memorychat.domain.model.ChatMessage
import com.memorychat.domain.model.Role
import com.memorychat.network.ChatCompletionRequest
import com.memorychat.network.StreamEvent
import com.memorychat.domain.model.WireMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeout

/**
 * 后台摘要任务（架构图节点「提交 WorkManager 异步生成摘要 → 后台执行 → 摘要生成完成?」）。
 *
 * 关键点：
 * 1. 任务只依赖「历史前缀 hash」，不依赖消息 id / 时间戳，保证同一段历史只生成一次；
 * 2. 执行时用当前历史重算 hash，与入参不一致就放弃（说明期间历史变了，缓存键已失效）；
 * 3. 生成成功立刻写入 summary_cache 并冻结，后续请求直接命中，不再重复消耗 token。
 */
class SummaryWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        if (!ServiceLocator.isInitialized) {
            return Result.failure(workDataOf(KEY_ERROR to "ServiceLocator 未初始化"))
        }
        val prefixHash = inputData.getString(KEY_PREFIX_HASH) ?: return Result.failure()
        val sessionId = inputData.getLong(KEY_SESSION_ID, 0L)
        if (sessionId <= 0L) return Result.failure()

        return try {
            val settings = ServiceLocator.settingsRepository.snapshot()
            if (!settings.llmEnabled) {
                // LLM 总开关关闭：不发起任何模型请求，直接失败让上层 fail-open。
                return Result.failure(workDataOf(KEY_ERROR to "LLM 调用已关闭"))
            }
            val assembler = PromptAssembler(recentRounds = settings.recentRounds)
            val history = ServiceLocator.database.messageDao()
                .listComplete(sessionId)
                .map { message ->
                    ChatMessage(
                        id = message.id,
                        role = Role.fromWire(message.role),
                        content = message.content,
                        createdAt = message.createdAt,
                    )
                }
            val split = assembler.split(history)
            if (split.compressible.isEmpty()) {
                return Result.failure(workDataOf(KEY_ERROR to "没有可压缩的历史"))
            }
            val currentHash = PrefixHash.of(split.compressible)
            if (currentHash != prefixHash) {
                // 历史已经变化，这个缓存键对应的摘要已经过时，直接放弃即可。
                return Result.failure(workDataOf(KEY_ERROR to "前缀 hash 已变化"))
            }

            val transcript = buildTranscript(split.compressible)
            val request = ChatCompletionRequest(
                model = settings.model,
                messages = listOf(
                    WireMessage(Role.SYSTEM, SUMMARY_SYSTEM_PROMPT),
                    WireMessage(Role.USER, transcript),
                ),
                temperature = SUMMARY_TEMPERATURE,
                maxTokens = SUMMARY_MAX_TOKENS,
                stream = false,
                // 摘要不需要思考模式：又快又省 token
                thinkingEnabled = false,
            )
            val summary = withTimeout(settings.summaryTimeoutMs) {
                ServiceLocator.chatClient.complete(request).text.trim()
            }
            if (summary.isBlank()) {
                return Result.failure(workDataOf(KEY_ERROR to "摘要为空"))
            }
            val now = System.currentTimeMillis()
            ServiceLocator.database.summaryCacheDao().upsert(
                SummaryCacheEntity(
                    prefixHash = prefixHash,
                    sessionId = sessionId,
                    summary = summary,
                    coveredMessages = split.compressible.size,
                    createdAt = now,
                    frozenAt = now,
                ),
            )
            Result.success(workDataOf(KEY_PREFIX_HASH to prefixHash))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(workDataOf(KEY_ERROR to (e.message ?: e.javaClass.simpleName)))
        }
    }

    private fun buildTranscript(messages: List<ChatMessage>): String = buildString {
        appendLine("以下是需要压缩的更早对话，请按系统要求生成摘要：")
        messages.forEach { message ->
            val speaker = if (message.role == Role.USER) "用户" else "助手"
            appendLine("$speaker：${message.content}")
        }
    }

    companion object {
        const val KEY_SESSION_ID = "session_id"
        const val KEY_PREFIX_HASH = "prefix_hash"
        const val KEY_ERROR = "error"

        private const val SUMMARY_TEMPERATURE = 0.3
        private const val SUMMARY_MAX_TOKENS = 900

        val SUMMARY_SYSTEM_PROMPT: String = """
            你是一个对话摘要器。请把用户提供的多轮对话压缩成一段可以代替原文的中文摘要。
            要求：
            1. 保留：人物称呼、已确认的事实、用户的偏好与雷点、未完成的事项、双方约定的暗号或梗、当前情绪基调；
            2. 删除：寒暄、重复内容、可以推断的过渡句；
            3. 用第三人称陈述，不评价、不添加原文没有的信息；
            4. 不要出现"摘要""压缩""模型"这类字眼，直接写内容；
            5. 控制在 300 字以内，条目化可以，但不要分点过多。
        """.trimIndent()
    }
}
