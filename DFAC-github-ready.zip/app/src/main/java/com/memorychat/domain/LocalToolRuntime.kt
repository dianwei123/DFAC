package com.memorychat.domain

import org.json.JSONException
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 本地工具执行器。模型发起 tool_calls 时由仓库层调用。
 *
 * 只实现只读的本地能力：查时间、检索本会话历史、查能力。写操作（改配置、发消息）不开放给模型。
 */
class LocalToolRuntime(
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
    private val searchHistory: suspend (query: String) -> List<String>,
    private val capabilityProvider: () -> String,
) {

    suspend fun execute(name: String, argumentsJson: String): String = when (name) {
        ToolCatalog.getCurrentTime.name -> currentTime()
        ToolCatalog.searchMemory.name -> searchMemory(argumentsJson)
        ToolCatalog.appCapabilities.name -> capabilityProvider()
        else -> errorJson("未知工具：$name")
    }

    private fun currentTime(): String {
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss (EEEE, z)", Locale.CHINA)
        return JSONObject()
            .put("datetime", formatter.format(Date(nowMillis())))
            .put("epoch_ms", nowMillis())
            .toString()
    }

    private suspend fun searchMemory(argumentsJson: String): String {
        val query = try {
            JSONObject(argumentsJson).optString("query", "")
        } catch (e: JSONException) {
            ""
        }
        if (query.isBlank()) return errorJson("缺少参数 query")
        val hits = searchHistory(query).take(MAX_SEARCH_HITS)
        return JSONObject()
            .put("query", query)
            .put("hit_count", hits.size)
            .put("hits", org.json.JSONArray(hits))
            .toString()
    }

    private fun errorJson(message: String): String =
        JSONObject().put("error", message).toString()

    companion object {
        private const val MAX_SEARCH_HITS = 5
    }
}
