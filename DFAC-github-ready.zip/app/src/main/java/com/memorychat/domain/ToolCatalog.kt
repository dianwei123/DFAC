package com.memorychat.domain

import com.memorychat.domain.model.ToolSpec

/**
 * 「全家桶工具参数」（架构图节点：注入配置里的工具参数）。
 *
 * 工具只声明 schema，真正的执行在 [LocalToolRuntime] 里完成，避免把副作用写进请求组装层。
 */
object ToolCatalog {

    val getCurrentTime = ToolSpec(
        name = "get_current_time",
        description = "获取设备当前日期与时间（含时区）。当用户询问现在几点、今天几号时调用。",
        parametersJson = """{"type":"object","properties":{},"additionalProperties":false}""",
    )

    val searchMemory = ToolSpec(
        name = "search_memory",
        description = "在当前会话的历史消息里检索关键词，返回匹配到的若干条原文片段。",
        parametersJson = """
            {"type":"object","properties":{"query":{"type":"string","description":"要检索的关键词或短语"}},"required":["query"],"additionalProperties":false}
        """.trimIndent(),
    )

    val appCapabilities = ToolSpec(
        name = "get_app_capabilities",
        description = "查询本机聊天助手具备的能力与当前设置（例如是否开启历史压缩、保留轮数）。",
        parametersJson = """{"type":"object","properties":{},"additionalProperties":false}""",
    )

    val ALL: List<ToolSpec> = listOf(getCurrentTime, searchMemory, appCapabilities)
}
