package com.memorychat.domain

/**
 * usage 快照（架构图节点「读取 usage 字段」）。
 *
 * DeepSeek 在 `usage` 里返回 `prompt_cache_hit_tokens` / `prompt_cache_miss_tokens`。
 */
data class UsageSnapshot(
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
    val cacheHitTokens: Int = 0,
    val cacheMissTokens: Int = 0,
) {
    /** 缓存命中率，分母用 promptTokens；DeepSeek 返回缺失时退化为 hit/(hit+miss)。 */
    val hitRate: Double
        get() {
            val denominator = when {
                promptTokens > 0 -> promptTokens
                else -> cacheHitTokens + cacheMissTokens
            }
            return if (denominator <= 0) 0.0 else cacheHitTokens.toDouble() / denominator
        }

    val hasUsage: Boolean get() = promptTokens > 0 || cacheHitTokens > 0 || cacheMissTokens > 0
}

/** 疑似让「静态前缀」失效的动态内容。 */
data class CacheSuspicion(
    val label: String,
    val samples: List<String>,
) {
    fun describe(): String = if (samples.isEmpty()) label else "$label（如 ${samples.first()}）"
}

/** 缓存体检结论（架构图节点「prompt_cache_hit_tokens 命中率正常?」）。 */
data class CacheDiagnosis(
    val hitRate: Double,
    val floor: Double,
    val healthy: Boolean,
    val suspicions: List<CacheSuspicion>,
    val summary: String,
)

/**
 * 动态内容探测：时间戳、日期、UUID、长随机串、动态关键词。
 * 这些内容一旦出现在 system prompt / 历史前缀里，前缀每轮都变，prompt cache 必然不命中。
 */
object DynamicContentDetector {

    private data class Rule(val label: String, val regex: Regex)

    private val rules: List<Rule> = listOf(
        Rule("ISO 时间戳", Regex("""\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2})?""")),
        Rule("中文日期", Regex("""\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日""")),
        Rule("斜杠日期", Regex("""\b\d{4}/\d{1,2}/\d{1,2}\b""")),
        Rule("UUID", Regex("""[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}""")),
        Rule("长十六进制串", Regex("""\b[0-9a-fA-F]{16,}\b""")),
        Rule(
            "动态关键词",
            Regex("""当前时间|现在时间|实时时间|本次会话|会话ID|request_id|random|nonce|timestamp""", RegexOption.IGNORE_CASE),
        ),
    )

    fun inspect(text: String, maxSamplesPerRule: Int = 2): List<CacheSuspicion> {
        if (text.isBlank()) return emptyList()
        return rules.mapNotNull { rule ->
            val samples = rule.regex.findAll(text)
                .map { it.value.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
                .take(maxSamplesPerRule)
                .toList()
            if (samples.isEmpty()) null else CacheSuspicion(rule.label, samples)
        }
    }
}

/**
 * 缓存体检器（架构图右侧「读取 usage → 命中率正常? → 偏低时标记该会话并检查
 * system/前缀是否含动态内容」）。
 */
class PromptCacheInspector(private val hitRateFloor: Double = DEFAULT_HIT_RATE_FLOOR) {

    fun diagnose(usage: UsageSnapshot, staticPrefix: String): CacheDiagnosis {
        val rate = usage.hitRate
        if (rate >= hitRateFloor) {
            return CacheDiagnosis(
                hitRate = rate,
                floor = hitRateFloor,
                healthy = true,
                suspicions = emptyList(),
                summary = "缓存命中率 ${percent(rate)}，正常",
            )
        }
        val suspicions = DynamicContentDetector.inspect(staticPrefix)
        val detail = if (suspicions.isEmpty()) {
            "未在前缀中发现明显动态内容，可能原因：历史被频繁改写、消息顺序不稳定，或首轮请求尚未建立缓存"
        } else {
            "前缀疑似含动态内容：" + suspicions.joinToString("；") { it.describe() }
        }
        return CacheDiagnosis(
            hitRate = rate,
            floor = hitRateFloor,
            healthy = false,
            suspicions = suspicions,
            summary = "缓存命中率 ${percent(rate)} 偏低（阈值 ${percent(hitRateFloor)}）。$detail",
        )
    }

    private fun percent(value: Double): String = "${(value * 100).toInt()}%"

    companion object {
        const val DEFAULT_HIT_RATE_FLOOR = 0.30
    }
}
