package com.memorychat.domain

/**
 * 指数退避重试策略（架构图节点「指数退避重试 最多 3 次」）。
 *
 * 只对 429 / 5xx 重试；4xx（除 429）属于请求本身有问题，重试没有意义，
 * 直接走「展示错误态，保留用户消息可重发」。
 */
class RetryPolicy(
    val maxAttempts: Int = DEFAULT_MAX_ATTEMPTS,
    private val baseDelayMs: Long = 800L,
    private val maxDelayMs: Long = 8_000L,
    private val jitterRatio: Double = 0.15,
    private val random: () -> Double = { Math.random() },
) {

    fun isRetryableStatus(statusCode: Int): Boolean =
        statusCode == 429 || statusCode in 500..599

    /** @param attempt 已经失败的次数，从 1 开始。 */
    fun delayMillisFor(attempt: Int): Long {
        val exponent = (attempt - 1).coerceIn(0, 5)
        val base = baseDelayMs shl exponent
        val capped = base.coerceAtMost(maxDelayMs)
        if (jitterRatio <= 0.0) return capped
        val jitter = (capped * jitterRatio * random()).toLong()
        return (capped + jitter).coerceAtMost(maxDelayMs)
    }

    fun hasAttemptsLeft(attempt: Int): Boolean = attempt < maxAttempts

    companion object {
        const val DEFAULT_MAX_ATTEMPTS = 3
    }
}
