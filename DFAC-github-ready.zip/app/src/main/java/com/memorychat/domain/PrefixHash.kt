package com.memorychat.domain

import com.memorychat.domain.model.ChatMessage
import java.security.MessageDigest

/**
 * 历史前缀 hash（架构图节点「计算历史前缀 hash」）。
 *
 * 设计要点：只让「语义内容」参与 hash，不能让 id、时间戳等易变字段参与，
 * 否则每轮 hash 都不同，summary_cache 永远不命中（也就永远拿不到 prompt cache 的好处）。
 */
object PrefixHash {

    /** 用与 [messages] 完全相同的卷序列化生成稳定 hash。 */
    fun of(messages: List<ChatMessage>): String {
        val canonical = StringBuilder()
        for (message in messages) {
            canonical.append(message.role.wire)
            canonical.append(FIELD_SEPARATOR)
            canonical.append(normalize(message.content))
            canonical.append(RECORD_SEPARATOR)
        }
        return sha256Hex(canonical.toString())
    }

    /** 统一换行、去掉首尾空白与多余行尾空格，避免"看起来一样但字节不同"导致缓存失效。 */
    fun normalize(content: String): String =
        content.replace("\r\n", "\n")
            .replace('\r', '\n')
            .lineSequence()
            .joinToString("\n") { it.trimEnd() }
            .trim()

    fun sha256Hex(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        val out = StringBuilder(digest.size * 2)
        for (byte in digest) {
            out.append(HEX[byte.toInt() shr 4 and 0x0F])
            out.append(HEX[byte.toInt() and 0x0F])
        }
        return out.toString()
    }

    private const val FIELD_SEPARATOR = "\u0001"
    private const val RECORD_SEPARATOR = "\u0002"
    private val HEX = "0123456789abcdef".toCharArray()
}
