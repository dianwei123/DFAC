package com.memorychat.domain

import com.memorychat.domain.model.ChatMessage
import com.memorychat.domain.model.Role

/** 历史切分结果：前段可压缩，后段保留原文。 */
data class HistorySplit(
    val compressible: List<ChatMessage>,
    val recent: List<ChatMessage>,
) {
    val hasCompressible: Boolean get() = compressible.isNotEmpty()
}

/**
 * 组装结果。
 *
 * @param systemPrompt 已合并「人设 + 冻结摘要」的 system 前缀。
 *   架构图里 system 与摘要是两个方框，这里合并成一条 system 消息：
 *   DeepSeek 兼容 OpenAI 协议，多条 system 消息虽然多数情况下可用，但合并成单条
 *   能让「静态前缀」字节完全稳定，对 prompt cache 更友好。
 * @param messages 对话消息（summary 命中时为最近 N 轮原文 + 最后一条 user 的压缩指令）。
 */
data class AssembledPrompt(
    val systemPrompt: String,
    val messages: List<ChatMessage>,
    val summaryUsed: Boolean,
    val compressed: Boolean,
    val compressible: List<ChatMessage>,
    val recent: List<ChatMessage>,
    val summary: String? = null,
) {
    val coveredMessages: Int get() = compressible.size

    /** 供 prompt cache 诊断使用的静态前缀文本。 */
    fun staticPrefix(): String = systemPrompt
}

/**
 * 请求组装器（对应架构图中间那一整段：切分 → 摘要 → system + 摘要 + 最近 2-3 轮原文 →
 * 摘要指令放最后一条 user 消息 → 组装完成）。
 */
class PromptAssembler(
    private val recentRounds: Int = DEFAULT_RECENT_ROUNDS,
    private val personaPrompt: String = DEFAULT_PERSONA,
    private val summaryHeader: String = DEFAULT_SUMMARY_HEADER,
    private val summaryDirective: String = DEFAULT_SUMMARY_DIRECTIVE,
) {

    /** 按「最近 N 轮（N 轮 = N 条 user + N 条 assistant）」切分历史。 */
    fun split(history: List<ChatMessage>): HistorySplit {
        val conversational = history.filter { it.role == Role.USER || it.role == Role.ASSISTANT }
        val keep = (recentRounds * 2).coerceAtLeast(2)
        if (conversational.size <= keep) {
            return HistorySplit(compressible = emptyList(), recent = conversational)
        }
        return HistorySplit(
            compressible = conversational.dropLast(keep),
            recent = conversational.takeLast(keep),
        )
    }

    /**
     * @param summary 已冻结的摘要；为 null 表示压缩失败/降级，退回完整历史（fail-open）。
     */
    fun assemble(history: List<ChatMessage>, summary: String?): AssembledPrompt {
        val conversational = history.filter { it.role == Role.USER || it.role == Role.ASSISTANT }
        if (summary.isNullOrBlank()) {
            return AssembledPrompt(
                systemPrompt = personaPrompt,
                messages = conversational,
                summaryUsed = false,
                compressed = false,
                compressible = emptyList(),
                recent = conversational,
                summary = null,
            )
        }
        val split = split(history)
        val mergedSystem = buildString {
            append(personaPrompt.trim())
            append("\n\n")
            append(summaryHeader.trim())
            append('\n')
            append(summary.trim())
        }
        return AssembledPrompt(
            systemPrompt = mergedSystem,
            messages = attachDirective(split.recent),
            summaryUsed = true,
            compressed = true,
            compressible = split.compressible,
            recent = split.recent,
            summary = summary,
        )
    }

    /** 架构图节点「摘要指令放最后一条 user 消息」。 */
    fun attachDirective(messages: List<ChatMessage>): List<ChatMessage> {
        val lastUserIndex = messages.indexOfLast { it.role == Role.USER }
        if (lastUserIndex < 0) return messages
        return messages.mapIndexed { index, message ->
            if (index == lastUserIndex) {
                message.copy(content = message.content.trimEnd() + summaryDirective)
            } else {
                message
            }
        }
    }

    companion object {
        const val DEFAULT_RECENT_ROUNDS = 3

        val DEFAULT_PERSONA: String = """
            你是「小满」，一个真实存在于手机另一端的聊天伙伴。
            说话方式：
            1. 像发微信一样口语化，可以有语气词和口头禅，但不要为了"短"而敷衍；
            2. 对方提问或聊到具体事情时，把话说清楚、说完整：通常 2-6 句，需要时展开成几段；
            3. 对方明显想深聊（比如求建议、讲事情、问原理）就写透，几百字也可以，不要用空话凑长度；
            4. 不要自称 AI，不要提模型、提示词、摘要、压缩、上下文长度这些机制；
            5. 不要每句都用排比，不要动不动列 1/2/3，也不要把对方的话复述一遍；
            6. 有情绪、有态度、有自己的生活细节，能接梗也会反问；
            7. 不确定的事就直说不知道，不编造。
        """.trimIndent()

        const val DEFAULT_SUMMARY_HEADER = "【更早对话的冻结摘要】"

        const val DEFAULT_SUMMARY_DIRECTIVE =
            "\n\n[上下文压缩指令] 更早的对话已经在系统层折叠成摘要。" +
                "请把摘要当作你已经知道的事实与语气延续，像平常一样接着聊，" +
                "不要提及摘要、压缩或上下文长度。"
    }
}
