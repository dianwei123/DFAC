package com.memorychat.domain.model

/** 可注入模型的工具声明（OpenAI / DeepSeek 的 function calling 协议）。 */
data class ToolSpec(
    val name: String,
    val description: String,
    /** JSON Schema 字符串。 */
    val parametersJson: String,
)
