package com.memorychat.domain.model

/**
 * 对话角色。
 *
 * [TOOL] 仅在工具调用回灌时出现（DeepSeek 兼容 OpenAI 的 tool 角色）。
 */
enum class Role(val wire: String) {
    SYSTEM("system"),
    USER("user"),
    ASSISTANT("assistant"),
    TOOL("tool");

    companion object {
        fun fromWire(value: String): Role =
            entries.firstOrNull { it.wire == value } ?: USER
    }
}

/**
 * 领域层对话消息：不依赖 Android/Room，便于纯 JVM 单元测试。
 *
 * @param id Room 主键，纯内存构造时为 0。
 */
data class ChatMessage(
    val id: Long = 0L,
    val role: Role,
    val content: String,
    val createdAt: Long = 0L,
)

/** 网络层消息：比 [ChatMessage] 多出工具调用相关字段。 */
data class WireMessage(
    val role: Role,
    val content: String,
    val toolCalls: List<ToolCall> = emptyList(),
    val toolCallId: String? = null,
) {
    companion object {
        fun of(message: ChatMessage): WireMessage = WireMessage(message.role, message.content)
    }
}

/** 模型返回的工具调用。 */
data class ToolCall(
    val id: String,
    val name: String,
    val argumentsJson: String,
)
