package com.memorychat.domain

import com.memorychat.domain.model.ChatMessage
import kotlin.math.ceil

/**
 * 历史 token 估算器。
 *
 * 架构图节点「估算历史 token 数」。真实 token 数需要分词器，App 里没有本地分词器，
 * 因此使用一个足够稳定的启发式估算：CJK 字符权重高于拉丁字符，并按消息加固定开销。
 * 估算只用于「是否触发压缩」的决策，少量误差不影响功能。
 */
interface TokenEstimator {
    fun estimate(text: String): Int

    fun estimate(messages: List<ChatMessage>): Int
}

class HeuristicTokenEstimator(
    private val perMessageOverhead: Int = 4,
    private val cjkWeight: Double = 0.62,
    private val latinCharsPerToken: Double = 3.6,
    private val minimumPerMessage: Int = 1,
) : TokenEstimator {

    override fun estimate(text: String): Int {
        if (text.isEmpty()) return 0
        var cjk = 0
        var other = 0
        for (ch in text) {
            if (isCjk(ch)) cjk++ else other++
        }
        val raw = cjk * cjkWeight + other / latinCharsPerToken
        return maxOf(1, ceil(raw).toInt())
    }

    override fun estimate(messages: List<ChatMessage>): Int =
        messages.sumOf { perMessageOverhead + maxOf(minimumPerMessage, estimate(it.content)) }

    private fun isCjk(ch: Char): Boolean = when (ch.code) {
        in 0x4E00..0x9FFF,   // CJK 统一表意文字
        in 0x3400..0x4DBF,   // 扩展 A
        in 0x3040..0x30FF,   // 日文假名
        in 0xAC00..0xD7AF,   // 韩文音节
        in 0x3000..0x303F,   // CJK 标点
        in 0xFF00..0xFFEF,   // 全角字符
        -> true
        else -> false
    }
}
