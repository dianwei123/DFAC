package com.memorychat.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RetryPolicyTest {

    private val policy = RetryPolicy(maxAttempts = 3, baseDelayMs = 800, jitterRatio = 0.0)

    @Test
    fun `429 与 5xx 可重试`() {
        assertTrue(policy.isRetryableStatus(429))
        assertTrue(policy.isRetryableStatus(500))
        assertTrue(policy.isRetryableStatus(503))
    }

    @Test
    fun `4xx 不可重试`() {
        assertFalse(policy.isRetryableStatus(400))
        assertFalse(policy.isRetryableStatus(401))
        assertFalse(policy.isRetryableStatus(402))
        assertFalse(policy.isRetryableStatus(404))
    }

    @Test
    fun `退避时间指数增长并有上限`() {
        assertEquals(800L, policy.delayMillisFor(1))
        assertEquals(1_600L, policy.delayMillisFor(2))
        assertEquals(3_200L, policy.delayMillisFor(3))
        assertEquals(8_000L, policy.delayMillisFor(10))
    }

    @Test
    fun `最多重试指定次数`() {
        assertTrue(policy.hasAttemptsLeft(1))
        assertTrue(policy.hasAttemptsLeft(2))
        assertFalse(policy.hasAttemptsLeft(3))
    }
}
