package com.memorychat.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CacheDiagnosticsTest {

    private val inspector = PromptCacheInspector(hitRateFloor = 0.30)

    @Test
    fun `命中率达标时健康`() {
        val diagnosis = inspector.diagnose(
            UsageSnapshot(promptTokens = 1000, cacheHitTokens = 800, cacheMissTokens = 200),
            staticPrefix = "你是一个聊天伙伴",
        )
        assertTrue(diagnosis.healthy)
        assertEquals(0.8, diagnosis.hitRate, 0.0001)
        assertTrue(diagnosis.suspicions.isEmpty())
    }

    @Test
    fun `命中率偏低时检出时间戳`() {
        val diagnosis = inspector.diagnose(
            UsageSnapshot(promptTokens = 1000, cacheHitTokens = 100, cacheMissTokens = 900),
            staticPrefix = "现在是 2025-01-08 14:30，你是聊天伙伴",
        )
        assertFalse(diagnosis.healthy)
        assertTrue(diagnosis.suspicions.any { it.label == "ISO 时间戳" })
        assertTrue(diagnosis.summary.contains("偏低"))    }

    @Test
    fun `命中率偏低时检出 uuid 与长随机串`() {
        val diagnosis = inspector.diagnose(
            UsageSnapshot(promptTokens = 500, cacheHitTokens = 20, cacheMissTokens = 480),
            staticPrefix = "会话 550e8400-e29b-41d4-a716-446655440000 前缀 9f86d081884c7d65",
        )
        val labels = diagnosis.suspicions.map { it.label }
        assertTrue(labels.contains("UUID"))
        assertTrue(labels.contains("长十六进制串"))
    }

    @Test
    fun `没有 usage 时命中率按 0 处理`() {
        assertEquals(0.0, UsageSnapshot().hitRate, 0.0)
        assertFalse(UsageSnapshot().hasUsage)
    }

    @Test
    fun `只有 hit 和 miss 时也能算出命中率`() {
        val usage = UsageSnapshot(cacheHitTokens = 30, cacheMissTokens = 70)
        assertEquals(0.3, usage.hitRate, 0.0001)
    }

    @Test
    fun `动态内容探测对干净前缀不误报`() {
        assertTrue(DynamicContentDetector.inspect("你是一个真实存在于手机另一端的聊天伙伴").isEmpty())
    }
}
