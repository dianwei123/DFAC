package com.memorychat.domain

import com.memorychat.domain.model.ChatMessage
import com.memorychat.domain.model.Role
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PromptAssemblerTest {

    private val assembler = PromptAssembler(recentRounds = 2)

    private fun history(turns: Int): List<ChatMessage> = buildList {
        repeat(turns) { index ->
            add(ChatMessage(id = index * 2L + 1, role = Role.USER, content = "用户消息$index"))
            add(ChatMessage(id = index * 2L + 2, role = Role.ASSISTANT, content = "助手回复$index"))
        }
    }

    @Test
    fun `不足保留轮数时全部保留`() {
        val split = assembler.split(history(1))
        assertTrue(split.compressible.isEmpty())
        assertEquals(2, split.recent.size)
    }

    @Test
    fun `切分保留最近 N 轮`() {
        val split = assembler.split(history(10))
        assertEquals(4, split.recent.size)
        assertEquals(16, split.compressible.size)
        assertEquals("用户消息8", split.recent.first().content)
    }

    @Test
    fun `没有摘要时使用完整历史且不压缩`() {
        val assembled = assembler.assemble(history(5), summary = null)
        assertFalse(assembled.compressed)
        assertFalse(assembled.summaryUsed)
        assertEquals(10, assembled.messages.size)
    }

    @Test
    fun `有摘要时 system 前缀包含摘要并只保留最近轮次`() {
        val assembled = assembler.assemble(history(10), summary = "用户在做周报，下周三要交")
        assertTrue(assembled.compressed)
        assertTrue(assembled.systemPrompt.contains("下周三要交"))
        assertTrue(assembled.systemPrompt.contains("小满"))
        assertEquals(4, assembled.messages.size)
        assertEquals(4, assembled.recent.size)
        assertEquals(16, assembled.coveredMessages)
    }

    @Test
    fun `摘要指令追加到最后一条 user 消息`() {
        val assembled = assembler.assemble(history(10), summary = "做了什么")
        val lastUser = assembled.messages.last { it.role == Role.USER }
        assertTrue(lastUser.content.endsWith(PromptAssembler.DEFAULT_SUMMARY_DIRECTIVE))
        assertTrue(lastUser.content.contains("用户消息9"))
    }

    @Test
    fun `空白摘要视为降级处理`() {
        val assembled = assembler.assemble(history(10), summary = "   ")
        assertFalse(assembled.compressed)
        assertEquals(20, assembled.messages.size)
    }

    @Test
    fun `system 消息不参与切分`() {
        val withSystem = listOf(
            ChatMessage(role = Role.SYSTEM, content = "旧 system"),
        ) + history(3)
        val split = assembler.split(withSystem)
        assertTrue(split.compressible.none { it.role == Role.SYSTEM })
    }
}
