package com.memorychat.domain

import com.memorychat.domain.model.ChatMessage
import com.memorychat.domain.model.Role
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class PrefixHashTest {

    private val history = listOf(
        ChatMessage(id = 1, role = Role.USER, content = "帮我记一下：下周三要交报告"),
        ChatMessage(id = 2, role = Role.ASSISTANT, content = "好，我记着了，下周三交报告"),
        ChatMessage(id = 3, role = Role.USER, content = "别忘了提醒我"),
    )

    @Test
    fun `同样的内容产生同样的 hash`() {
        assertEquals(PrefixHash.of(history), PrefixHash.of(history))
    }

    @Test
    fun `id 和时间戳不参与 hash`() {
        val shifted = history.mapIndexed { index, message ->
            message.copy(id = message.id + 100, createdAt = 9_999_999L + index)
        }
        assertEquals(PrefixHash.of(history), PrefixHash.of(shifted))
    }

    @Test
    fun `换行与行尾空白被归一化`() {
        val a = listOf(ChatMessage(role = Role.USER, content = "line1\nline2"))
        val b = listOf(ChatMessage(role = Role.USER, content = "line1  \r\nline2   "))
        assertEquals(PrefixHash.of(a), PrefixHash.of(b))
    }

    @Test
    fun `角色变化会改变 hash`() {
        val swapped = listOf(history[0].copy(role = Role.ASSISTANT)) + history.drop(1)
        assertNotEquals(PrefixHash.of(history), PrefixHash.of(swapped))
    }

    @Test
    fun `内容变化会改变 hash`() {
        val edited = history.dropLast(1) + history.last().copy(content = "别忘了提醒我！")
        assertNotEquals(PrefixHash.of(history), PrefixHash.of(edited))
    }
}
