package com.memorychat.domain

import com.memorychat.domain.model.ChatMessage
import com.memorychat.domain.model.Role
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TokenEstimatorTest {

    private val estimator = HeuristicTokenEstimator()

    @Test
    fun `空字符串估算为 0`() {
        assertEquals(0, estimator.estimate(""))
    }

    @Test
    fun `同字符数下中文比英文更贵`() {
        val chinese = "今天下午一起喝杯咖啡吧呀"
        val english = "abcdefghijkl"
        assertEquals(chinese.length, english.length)
        assertTrue(
            "同字符数时中文 token 权重应更高",
            estimator.estimate(chinese) > estimator.estimate(english),
        )
    }

    @Test
    fun `同义句子的中文估算低于英文`() {
        // 中文用一个字表达的信息，英文往往要好几个字母，所以整句估算中文更省。
        val chinese = "今天下午一起去喝杯咖啡怎么样"
        val english = "how about grabbing a coffee together this afternoon"
        assertTrue(estimator.estimate(chinese) < estimator.estimate(english))
    }

    @Test
    fun `消息列表带固定开销`() {
        val messages = listOf(
            ChatMessage(role = Role.USER, content = "你好"),
            ChatMessage(role = Role.ASSISTANT, content = "在的"),
        )
        val sum = messages.sumOf { estimator.estimate(it.content) }
        val withOverhead = estimator.estimate(messages)
        assertEquals(sum + messages.size * 4, withOverhead)
    }

    @Test
    fun `估算随内容单调递增`() {
        val short = estimator.estimate("今天天气不错")
        val long = estimator.estimate("今天天气不错，".repeat(20))
        assertTrue(long > short)
    }
}
