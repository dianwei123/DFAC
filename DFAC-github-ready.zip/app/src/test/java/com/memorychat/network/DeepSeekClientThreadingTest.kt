package com.memorychat.network

import com.memorychat.data.settings.AppSettings
import com.memorychat.domain.RetryPolicy
import com.memorychat.domain.model.Role
import com.memorychat.domain.model.WireMessage
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * 用 MockWebServer 验证 OkHttp 客户端的线程与解析行为。
 *
 * 重点回归：非流式 `complete()` 是阻塞调用，必须切到 IO 线程，
 * 否则在 UI 线程调用「测试连接」会抛 NetworkOnMainThreadException。
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DeepSeekClientThreadingTest {

    private lateinit var server: MockWebServer
    private lateinit var client: DeepSeekHttpClient
    private var requestThreadName: String? = null

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                requestThreadName = Thread.currentThread().name
                chain.proceed(chain.request())
            }
            .build()
        val settings = AppSettings(
            apiKey = "sk-test",
            baseUrl = server.url("/").toString(),
        )
        client = DeepSeekHttpClient(settingsProvider = { settings }, client = okHttpClient)
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    private fun request(): ChatCompletionRequest = ChatCompletionRequest(
        model = "deepseek-flash",
        messages = listOf(WireMessage(Role.USER, "ping")),
        temperature = 0.0,
        maxTokens = 16,
        stream = false,
    )

    @Test
    fun `complete 切到 IO 线程执行网络请求`() {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """
                {"choices":[{"message":{"role":"assistant","content":"ok"},"finish_reason":"stop"}],
                 "usage":{"prompt_tokens":3,"completion_tokens":1,
                          "prompt_cache_hit_tokens":2,"prompt_cache_miss_tokens":1}}
                """.trimIndent(),
            ),
        )
        val callerThread = Thread.currentThread().name

        val result = runBlocking { client.complete(request()) }

        assertEquals("ok", result.text)
        assertEquals(3, result.usage?.promptTokens)
        assertEquals(2, result.usage?.cacheHitTokens)
        assertNotEquals(
            "阻塞网络请求不能在调用线程（UI 线程）上执行",
            callerThread,
            requestThreadName,
        )
    }

    @Test
    fun `非 200 返回 ApiException 且带状态码`() {
        server.enqueue(
            MockResponse().setResponseCode(401)
                .setBody("""{"error":{"message":"invalid key"}}"""),
        )

        val error = runCatching { runBlocking { client.complete(request()) } }.exceptionOrNull()

        assertTrue("应抛出 ApiException", error is ApiException)
        assertEquals(401, (error as ApiException).statusCode)
        assertTrue("401 不应被当成可重试错误", !error.retryable)
    }

    @Test
    fun `请求体按官方文档带上 model 与 thinking 参数`() {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"choices":[{"message":{"content":"ok"},"finish_reason":"stop"}]}""",
            ),
        )

        runBlocking {
            client.complete(request().copy(thinkingEnabled = false, reasoningEffort = "high"))
        }

        val recorded = server.takeRequest()
        val body = recorded.body.readUtf8()
        assertEquals("/chat/completions", recorded.path)
        assertTrue("应使用官方模型 ID", body.contains("\"model\":\"deepseek-flash\""))
        assertTrue(
            "关闭思考时应显式下发 thinking.disabled",
            body.contains("\"thinking\":{\"type\":\"disabled\"}"),
        )
        assertTrue("关闭思考时不应下发 reasoning_effort", !body.contains("reasoning_effort"))
    }

    @Test
    fun `开启思考模式时下发 reasoning_effort`() {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"choices":[{"message":{"content":"ok","reasoning_content":"think"},"finish_reason":"stop"}]}""",
            ),
        )

        runBlocking {
            client.complete(request().copy(thinkingEnabled = true, reasoningEffort = "max"))
        }

        val body = server.takeRequest().body.readUtf8()
        assertTrue(body.contains("\"thinking\":{\"type\":\"enabled\"}"))
        assertTrue(body.contains("\"reasoning_effort\":\"max\""))
    }

    @Test
    fun `listModels 解析官方 GET models 接口`() {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """
                {"object":"list","data":[
                  {"id":"deepseek-flash","object":"model","owned_by":"deepseek"},
                  {"id":"deepseek-v4-pro","object":"model","owned_by":"deepseek"}
                ]}
                """.trimIndent(),
            ),
        )

        val models = runBlocking { client.listModels() }

        assertEquals(listOf("deepseek-flash", "deepseek-v4-pro"), models)
        assertEquals("/models", server.takeRequest().path)
    }

    @Test
    fun `stream 区分 reasoning_content 与 content`() = runBlocking {
        val sse = buildString {
            append("""data: {"choices":[{"delta":{"reasoning_content":"先想"},"index":0}]}""").append("\n\n")
            append("""data: {"choices":[{"delta":{"reasoning_content":"一下"},"index":0}]}""").append("\n\n")
            append("""data: {"choices":[{"delta":{"content":"你"},"index":0}]}""").append("\n\n")
            append("""data: {"choices":[{"delta":{"content":"好"},"index":0}]}""").append("\n\n")
            append("data: [DONE]").append("\n\n")
        }
        server.enqueue(
            MockResponse().setResponseCode(200)
                .setHeader("Content-Type", "text/event-stream")
                .setBody(sse),
        )

        val events = client.stream(request(), RetryPolicy()).toList()

        val reasoning = events.filterIsInstance<StreamEvent.Reasoning>().joinToString("") { it.text }
        val content = events.filterIsInstance<StreamEvent.Delta>().joinToString("") { it.text }
        assertEquals("先想一下", reasoning)
        assertEquals("你好", content)
    }

    @Test
    fun `联网搜索请求声明 deepseek_web_search 服务端工具`() {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"choices":[{"message":{"content":"ok"},"finish_reason":"stop"}]}""",
            ),
        )

        runBlocking { client.complete(request().copy(webSearchEnabled = true)) }

        val recorded = server.takeRequest()
        val body = recorded.body.readUtf8()
        assertEquals("/chat/completions", recorded.path)
        assertTrue(
            "联网搜索应声明官方服务端工具",
            body.contains("\"tools\":[{\"type\":\"deepseek_web_search\"}]"),
        )
        assertTrue("联网工具不能用 tool_choice 指定", !body.contains("tool_choice"))
    }

    @Test
    fun `stream 解析联网工具事件与引用来源`() = runBlocking {
        val sse = buildString {
            append(
                """data: {"choices":[{"delta":{},"server_tool_event":{"type":"call_started",""" +
                    """"step":0,"call":{"type":"deepseek_web_search","kind":"search",""" +
                    """"action":{"type":"search","queries":["DeepSeek V4.1"]}}}}]}""",
            ).append("\n\n")
            append(
                """data: {"choices":[{"delta":{"content":"答案"},"server_tool_event":{"type":"call_completed",""" +
                    """"step":0,"call":{"type":"deepseek_web_search","kind":"search","status":"completed",""" +
                    """"sources":[{"type":"url","url":"https://example.com/a","title":"示例 A"}]}}}]}""",
            ).append("\n\n")
            append("data: [DONE]").append("\n\n")
        }
        server.enqueue(
            MockResponse().setResponseCode(200)
                .setHeader("Content-Type", "text/event-stream")
                .setBody(sse),
        )

        val events = client.stream(
            request().copy(webSearchEnabled = true),
            RetryPolicy(),
        ).toList()

        val toolMessages = events.filterIsInstance<StreamEvent.WebToolEvent>().map { it.message }
        assertTrue("应解析出搜索动作", toolMessages.any { it.contains("联网搜索") })
        assertTrue("应解析出搜索完成", toolMessages.any { it.contains("联网完成") })

        val sources = events.filterIsInstance<StreamEvent.Sources>().single().items
        assertEquals(1, sources.size)
        assertEquals("示例 A", sources.first().title)
        assertEquals("https://example.com/a", sources.first().url)
    }

    @Test
    fun `stream 能逐段解析 delta 与 usage`() = runBlocking {
        val sse = buildString {
            append("""data: {"choices":[{"delta":{"content":"你"},"index":0}]}""").append("\n\n")
            append("""data: {"choices":[{"delta":{"content":"好"},"index":0}]}""").append("\n\n")
            append(
                """data: {"choices":[],"usage":{"prompt_tokens":10,"completion_tokens":2,""" +
                    """"prompt_cache_hit_tokens":7,"prompt_cache_miss_tokens":3}}""",
            ).append("\n\n")
            append("data: [DONE]").append("\n\n")
        }
        server.enqueue(
            MockResponse().setResponseCode(200)
                .setHeader("Content-Type", "text/event-stream")
                .setBody(sse),
        )

        val events = client.stream(request(), RetryPolicy()).toList()

        val text = events.filterIsInstance<StreamEvent.Delta>().joinToString("") { it.text }
        assertEquals("你好", text)
        val usage = events.filterIsInstance<StreamEvent.UsageReported>().first().usage
        assertEquals(10, usage.promptTokens)
        assertEquals(7, usage.cacheHitTokens)
        assertEquals(0.7, usage.hitRate, 0.0001)
    }
}
