package com.memorychat.integration

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.work.ListenableWorker
import androidx.work.testing.TestListenableWorkerBuilder
import androidx.work.workDataOf
import com.memorychat.DfacApp
import com.memorychat.data.local.MessageEntity
import com.memorychat.data.local.MessageStatus
import com.memorychat.data.local.SummaryCacheEntity
import com.memorychat.data.repo.ChatRepository
import com.memorychat.data.repo.TurnPhase
import com.memorychat.data.repo.TurnSink
import com.memorychat.data.repo.TurnStatus
import com.memorychat.data.settings.AppSettings
import com.memorychat.di.ServiceLocator
import com.memorychat.domain.PrefixHash
import com.memorychat.domain.PromptAssembler
import com.memorychat.domain.model.ChatMessage
import com.memorychat.domain.model.Role
import com.memorychat.work.SummaryWorker
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * 运行时冒烟测试（Robolectric，不需要真机/模拟器）：
 * 验证 Room 建库、SSE 流式链路（离线 Mock）、压缩命中路径、以及摘要 Worker 落库，
 * 确保不是"只编译通过"。
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], application = DfacApp::class)
class ChatPipelineRobolectricTest {

    private val context: Context get() = ApplicationProvider.getApplicationContext()

    private val repository: ChatRepository get() = ServiceLocator.repository

    @Before
    fun setUp() = runBlocking {
        ServiceLocator.database.messageDao().clearAll()
        ServiceLocator.database.sessionDao().clearAll()
        ServiceLocator.database.summaryCacheDao().clearAll()
        ServiceLocator.settingsRepository.save(
            AppSettings(apiKey = "", tokenThreshold = 1_000_000, recentRounds = 3),
        )
    }

    @Test
    fun `离线 Mock 模式下完整链路跑通并记录 usage 缓存命中率`() = runBlocking {
        val sessionId = repository.createSession()
        val sink = RecordingSink()

        repository.send(sessionId, "你好呀，今天有点累", sink)

        val messages = repository.observeMessages(sessionId).first { it.size >= 2 }
        assertEquals(2, messages.size)
        assertEquals("user", messages[0].role)
        assertEquals(MessageStatus.COMPLETE, messages[0].status)
        assertEquals("assistant", messages[1].role)
        assertEquals(MessageStatus.COMPLETE, messages[1].status)
        assertTrue("助手回复不应为空", messages[1].content.isNotBlank())
        assertTrue("usage 应写回消息", messages[1].promptTokens > 0)

        assertTrue(sink.phases.contains(TurnPhase.REQUESTING))
        assertTrue(sink.phases.contains(TurnPhase.DONE))
        assertTrue("流式回调应至少推送一次完整文本", sink.texts.values.any { it.isNotBlank() })
        assertTrue("不应出现错误", sink.errors.isEmpty())

        val session = repository.sessionSnapshot(sessionId)
        assertNotNull(session)
        assertTrue("Mock 返回 usage，命中率应被记录", session!!.cacheHitRate > 0.0)
        assertNull("命中率 35% 高于 30% 阈值，不应产生体检告警", session.cacheDiag)
        assertEquals(0, session.compressedRounds)
    }

    @Test
    fun `超过阈值时命中已冻结摘要并累计压缩统计`() = runBlocking {
        ServiceLocator.settingsRepository.save(
            AppSettings(apiKey = "", tokenThreshold = 60, recentRounds = 1),
        )
        val sessionId = repository.createSession()

        // 预置 6 条历史（3 轮），再发一条新消息：
        // 保留最近 1 轮，所以发消息后可压缩的是「预置历史的前 5 条」。
        val seeded = seedHistory(sessionId, rounds = 3)
        val compressible = seeded.dropLast(1)
        val hash = PrefixHash.of(compressible)
        val now = System.currentTimeMillis()
        ServiceLocator.database.summaryCacheDao().upsert(
            SummaryCacheEntity(
                prefixHash = hash,
                sessionId = sessionId,
                summary = "用户最近在赶一个项目，情绪有些疲惫，约定周末一起吃饭。",
                coveredMessages = compressible.size,
                createdAt = now,
                frozenAt = now,
            ),
        )

        val sink = RecordingSink()
        repository.send(sessionId, "那我们周末几点见？", sink)

        assertTrue("应命中 summary_cache", sink.phases.contains(TurnPhase.SUMMARY_READY))
        assertTrue("应完成整轮", sink.phases.contains(TurnPhase.DONE))
        assertTrue("不应降级", sink.statuses.none { it.degraded })

        val session = repository.sessionSnapshot(sessionId)
        assertNotNull(session)
        assertTrue("压缩轮数应累计", session!!.compressedRounds > 0)
        assertTrue("节省 token 应大于 0", session.savedTokens > 0)

        val messages = repository.observeMessages(sessionId).first { it.size >= 2 }
        assertTrue("最后一轮助手回复非空", messages.last().content.isNotBlank())
    }

    @Test
    fun `摘要 Worker 生成摘要并冻结写入 summary_cache`() = runBlocking {
        ServiceLocator.settingsRepository.save(
            AppSettings(apiKey = "", tokenThreshold = 100, recentRounds = 1),
        )
        val sessionId = repository.createSession()
        val seeded = seedHistory(sessionId, rounds = 2)
        val assembler = PromptAssembler(recentRounds = 1)
        val compressible = assembler.split(seeded).compressible
        val hash = PrefixHash.of(compressible)

        val worker = TestListenableWorkerBuilder<SummaryWorker>(context)
            .setInputData(
                workDataOf(
                    SummaryWorker.KEY_SESSION_ID to sessionId,
                    SummaryWorker.KEY_PREFIX_HASH to hash,
                ),
            )
            .build()
        val result = worker.doWork()

        assertTrue("Worker 应成功", result is ListenableWorker.Result.Success)
        val cached = ServiceLocator.database.summaryCacheDao().find(hash)
        assertNotNull("摘要应写入 summary_cache", cached)
        assertTrue("摘要内容非空", cached!!.summary.isNotBlank())
        assertNotNull("摘要应被冻结", cached.frozenAt)
        assertEquals(compressible.size, cached.coveredMessages)
    }

    @Test
    fun `LLM 总开关关闭时不发请求只落库`() = runBlocking {
        ServiceLocator.settingsRepository.save(
            AppSettings(apiKey = "", llmEnabled = false, tokenThreshold = 60),
        )
        val sessionId = repository.createSession()
        val sink = RecordingSink()

        repository.send(sessionId, "关掉模型之后，我发的消息还会保存吗？", sink)

        val messages = repository.observeMessages(sessionId).first { it.size >= 2 }
        assertEquals(2, messages.size)
        assertEquals("user", messages[0].role)
        assertEquals(MessageStatus.COMPLETE, messages[0].status)
        assertTrue(
            "关闭时助手应给出本地提示而不是模型回复",
            messages[1].content.contains("LLM 已手动关闭"),
        )
        assertTrue("不应发起请求，因此不应产生错误", sink.errors.isEmpty())
        assertTrue(sink.phases.contains(TurnPhase.DONE))
        assertTrue(
            "应提示 LLM 已关闭",
            sink.statuses.any { it.message.contains("LLM 已关闭") },
        )
    }

    @Test
    fun `旧版偏小的设置值与已下线模型在升级后被纠正`() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val prefs = ctx.getSharedPreferences("memory_chat_settings", Context.MODE_PRIVATE)

        // 官方 2026 文档：deepseek-chat / deepseek-reasoner 已下线，只保留 flash / v4-pro
        listOf("deepseek-chat", "deepseek-reasoner", "some-gateway-model").forEach { legacyModel ->
            prefs.edit()
                .clear()
                .putString(AppSettings.KEY_MODEL, legacyModel)
                .putInt(AppSettings.KEY_MAX_TOKENS, 2_048)
                .putInt(AppSettings.KEY_TOKEN_THRESHOLD, 8_000)
                .putInt(AppSettings.KEY_SETTINGS_VERSION, 0)
                .commit()

            val migrated = com.memorychat.data.settings.SettingsRepository(ctx).snapshot()

            assertEquals("已下线模型应纠正为 deepseek-flash", "deepseek-flash", migrated.model)
            assertTrue("max_tokens 应被抬到至少 4096", migrated.maxTokens >= 4_096)
            assertTrue("压缩阈值应被抬到至少 16000", migrated.tokenThreshold >= 16_000)
        }

        // 合法模型 deepseek-v4-pro 不应被改掉
        prefs.edit()
            .clear()
            .putString(AppSettings.KEY_MODEL, "deepseek-v4-pro")
            .putInt(AppSettings.KEY_SETTINGS_VERSION, 0)
            .commit()
        val kept = com.memorychat.data.settings.SettingsRepository(ctx).snapshot()
        assertEquals("deepseek-v4-pro", kept.model)
    }

    @Test
    fun `历史对话可以列出、切换与删除`() = runBlocking {
        val first = repository.createSession()
        repository.send(first, "第一段对话：今天吃什么", RecordingSink())
        val second = repository.createSession()
        repository.send(second, "第二段对话：周末去哪玩", RecordingSink())

        val sessions = repository.observeSessions().first { it.size >= 2 }
        assertTrue("应能看到两个会话", sessions.any { it.id == first } && sessions.any { it.id == second })
        assertTrue("会话标题应取首条消息", sessions.any { it.title.contains("今天吃什么") })

        // 两个会话的消息互不串台
        val firstMessages = repository.observeMessages(first).first { it.size >= 2 }
        assertTrue(firstMessages.all { it.sessionId == first })

        repository.deleteSession(first)
        val afterDelete = repository.observeSessions().first { list -> list.none { it.id == first } }
        assertTrue("删除后会话应消失", afterDelete.none { it.id == first })
        assertEquals("删除会话应连带清空消息", 0, ServiceLocator.database.messageDao().count(first))
    }

    // ------------------------------------------------------------------ 工具

    private suspend fun seedHistory(sessionId: Long, rounds: Int): List<ChatMessage> {
        val contents = listOf(
            "最近项目压得我有点喘不过气，天天加班到很晚。",
            "听着就累，先别硬扛，晚上早点睡吧。",
            "嗯……周末可能会好一点，想出去走走。",
            "那挺好的，要不要一起去吃那家新开的面馆？",
        )
        val result = mutableListOf<ChatMessage>()
        val now = System.currentTimeMillis()
        repeat(rounds) { round ->
            val userText = contents[round % contents.size]
            val assistantText = "好呀，我记着了（第${round}轮）"
            val userEntity = MessageEntity(
                sessionId = sessionId,
                role = "user",
                content = userText,
                status = MessageStatus.COMPLETE,
                createdAt = now + round * 10,
            )
            val assistantEntity = MessageEntity(
                sessionId = sessionId,
                role = "assistant",
                content = assistantText,
                status = MessageStatus.COMPLETE,
                createdAt = now + round * 10 + 1,
            )
            val userId = ServiceLocator.database.messageDao().insert(userEntity)
            val assistantId = ServiceLocator.database.messageDao().insert(assistantEntity)
            result += ChatMessage(userId, Role.USER, userEntity.content, userEntity.createdAt)
            result += ChatMessage(
                assistantId,
                Role.ASSISTANT,
                assistantEntity.content,
                assistantEntity.createdAt,
            )
        }
        return result
    }

    private class RecordingSink : TurnSink {
        val phases = mutableListOf<TurnPhase>()
        val statuses = mutableListOf<TurnStatus>()
        val texts = mutableMapOf<Long, String>()
        val errors = mutableListOf<String>()

        override suspend fun onAssistantText(messageId: Long, fullText: String) {
            texts[messageId] = fullText
        }

        override suspend fun onStatus(status: TurnStatus) {
            phases += status.phase
            statuses += status
        }

        override suspend fun onError(message: String, retryable: Boolean) {
            errors += message
        }
    }
}
