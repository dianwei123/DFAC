// 顶层构建脚本：只声明插件版本，具体配置在各模块中完成。
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.ksp) apply false
}

// 生成 wrapper 时不联网校验分发地址（离线/内网环境也能生成）。
tasks.wrapper {
    gradleVersion = "8.11.1"
    distributionType = Wrapper.DistributionType.BIN
    validateDistributionUrl = false
}
