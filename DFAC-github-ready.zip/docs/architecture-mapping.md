# 架构图 ↔ 代码逐节点映射

> 左列：架构图里的方框 / 菱形（原图中文字）
> 右列：本工程中实现该节点的文件与方法

| # | 架构图节点 | 实现位置 | 说明 |
| --- | --- | --- | --- |
| 1 | 用户输入消息 | `ui/chat/ChatActivity#submit`：`ChatViewModel#send` | 输入框 + 发送按钮，IME 的 actionSend 也可发送 |
| 2 | 写入 Room: messages 表 | `data/local/Entities.kt` `MessageEntity`、`data/local/Daos.kt` `MessageDao#insert` | 先落 user 消息（`status=complete`），再开始链路 |
| 3 | 估算历史 token 数 | `domain/TokenEstimator.kt` `HeuristicTokenEstimator` | CJK 0.62 token/字、拉丁 3.6 字符/token、每条 +4 开销 |
| 4 | ≤ 阈值 → 拼接完整历史 | `PromptAssembler#assemble(history, summary = null)` | 返回原始全部历史，`compressed=false` |
| 5 | > 阈值 → 触发压缩流程 | `data/repo/ChatRepository#completeTurn`（`estimatedTokens > tokenThreshold` 分支） | 阈值默认 8000，可在设置页改 |
| 6 | 计算历史前缀 hash | `domain/PrefixHash.kt#of` | SHA-256(role + \u0001 + 归一化内容 + \u0002 …)，**忽略 id / 时间戳 / 行尾空白** |
| 7 | summary_cache 中已有该 hash? | `data/local/Daos.kt` `SummaryCacheDao#find(prefixHash)` | `summary_cache` 主键就是 prefixHash；命中即读冻结摘要 |
| 8 | 未命中 → 提交 WorkManager 异步生成摘要 | `work/SummaryScheduler.kt#scheduleAndAwait` | `enqueueUniqueWork(KEEP)`，唯一名 = `history_summary:会话id:hash前16位` |
| 9 | 后台执行 | `work/SummaryWorker.kt#doWork` | 重新从 Room 读历史、重算 hash 校验、拼 transcript、调模型生成 |
| 10 | 摘要生成完成? | `SummaryWorker` 成功返回 `Result.success`；`SummaryScheduler` 用 `getWorkInfosForUniqueWorkFlow` 等状态 | 用 `withTimeout(摘要超时 + 3s)` 等待 |
| 11 | 是 → 写入 summary_cache 冻结摘要 | `SummaryWorker` 内 `summaryCacheDao.upsert(SummaryCacheEntity(frozenAt = now))` | 冻结后同 hash 永不重算 |
| 12 | 否 / 超时 → 降级：原文转发 fail-open | `ChatRepository#completeTurn` 的 `degraded` 分支 + `TurnStatus(DEGRADED)` | 本轮改用完整历史；后台任务不取消，跑完仍写缓存 |
| 13 | 读取冻结摘要 | `ChatRepository`：命中时读 `cached.summary`，未命中生成后回读 `summaryCacheDao.find(hash)` | 只有写完 DB 才读，避免内存/DB 不一致 |
| 14 | 组装请求：system + 摘要 + 最近 2-3 轮原文 | `domain/PromptAssembler.kt#assemble` + `#split` | `split` 按「最近 recentRounds 轮」切；摘要合并进 system 前缀 |
| 15 | 摘要指令放最后一条 user 消息 | `PromptAssembler#attachDirective` | `DEFAULT_SUMMARY_DIRECTIVE` 追加到最近一条 user 消息尾部，不改动其它字节 |
| 16 | 组装完成 | `ChatRepository` 构造 `List<WireMessage>`（system + 组装结果） | 网络层 DTO 与领域模型分离 |
| 17 | 注入配置：temperature=1.3 / 活人感 System Prompt / 全家桶工具参数 | `data/settings/AppSettings.kt`（temperature 默认 1.3）、`PromptAssembler.DEFAULT_PERSONA`、`domain/ToolCatalog.kt` | 工具参数可通过侧边栏开关；默认关闭。按官方 2026 文档额外注入 `thinking`（默认 `disabled`，聊天更快）与 `reasoning_effort`；**LLM 总开关关闭时在进入本节点前就短路**（见 `ChatRepository#completeOfflineTurn`） |
| 18 | OkHttp 发起 SSE 请求 DeepSeek API | `network/DeepSeekHttpClient.kt#stream` → `attemptStream` | `stream=true`、`stream_options.include_usage=true`、`Accept: text/event-stream`；思考模式的 `delta.reasoning_content` 解析为独立事件，不进气泡；联网搜索时 `tools` 里声明 `deepseek_web_search`，并解析 `server_tool_event` 与 `annotations`/`sources` |
| 19 | HTTP 响应状态 | `DeepSeekHttpClient#attemptStream` 的 `response.isSuccessful` 判定 → `ApiException(statusCode)` | 区分 200 / 429 / 5xx / 4xx |
| 20 | 429 / 5xx → 指数退避重试最多 3 次 | `network/DeepSeekHttpClient#stream` retry 循环 + `domain/RetryPolicy.kt` | 800 → 1600 → 3200ms（带 15% 抖动，上限 8s），默认 3 次尝试，可设置 |
| 21 | 4xx 不可重试 → 展示错误态、保留用户消息可重发 | `ChatRepository#failTurn` + `MessageEntity.status=error` + `MessageAdapter` 点击重发 | 用户消息保持 `complete`，点错误气泡 → `ChatViewModel#retryLast` → `ChatRepository#regenerate` |
| 22 | 200 流式 → 逐 chunk 解析、更新最后一条气泡 | `DeepSeekHttpClient#attemptStream` 逐行读 `data:` → `StreamEvent.Delta`；`ChatViewModel#onAssistantText` 即时刷新 UI | 内存 sink 实时刷新，Room 每 350ms 落一次 |
| 23 | 流结束：写入完整回复 | `ChatRepository`：`messageDao.updateContent(assistantId, finalText, COMPLETE)` | 同时把 usage 写入该消息 |
| 24 | 读取 usage 字段 | `DeepSeekHttpClient#parseUsage` | `prompt_tokens` / `completion_tokens` / `prompt_cache_hit_tokens` / `prompt_cache_miss_tokens`（并兼容 OpenAI `prompt_tokens_details.cached_tokens`） |
| 25 | prompt_cache_hit_tokens 命中率正常? | `domain/CacheDiagnostics.kt#PromptCacheInspector.diagnose` | `hitRate = hit / prompt_tokens`，低于阈值（默认 30%）判为异常 |
| 26 | 偏低 → 标记该会话 + 检查 system/前缀是否含动态内容 | `ChatRepository#applyDiagnosis` + `SessionDao#updateCacheStats` + `DynamicContentDetector` | 扫 ISO 时间戳 / 日期 / UUID / 长 hex / 动态关键词，结论写进会话并在 UI 顶部黄条展示 |
| 27 | 更新压缩状态条：已压缩 X 轮 / 节省 Y tokens | `SessionDao#bumpCompression` + `ChatViewModel#refreshSessionInfo` / `ChatActivity` 顶部 `textStatus` | 节省量 = 可压缩原文估算 − 摘要估算（≥0） |
| 28 | UI 渲染完成 | `ui/chat/MessageAdapter.kt`、`ui/chat/ChatActivity.kt` | 用户气泡右、助手气泡左、流式带光标、错误可点重发；顶部 4 个 token 消耗 chip（上下文/本轮/缓存/压缩）；设置放在右侧 DrawerLayout 抽屉；输入区用 `WindowInsets.ime()` 避让键盘 |

## 时序要点（源码注释里也有）

1. `ChatRepository#completeTurn` 是唯一主干，`send` / `regenerate` 都走它。
2. 压缩只发生一次：同 hash 的摘要冻结后，后续轮次直接命中。
3. fail-open 有两条路径：摘要超时（degraded）、网络彻底失败（错误态）。
4. 状态机：`ESTIMATING → COMPRESSING → SUMMARY_READY/DEGRADED → REQUESTING → (RETRYING) → CACHE_CHECK → DONE`。
5. 设置项全部落在 `AppSettings`，`SwitchingChatCompletionClient` 根据「是否填了 Key」实时在真实客户端与 Mock 之间切换，无需重启。
6. **LLM 总开关**（`AppSettings.llmEnabled`）不在这张图的正常分支里：关闭时链路在「估算历史 token」之后直接短路到本地提示消息，既不组装请求、也不入队摘要 Worker。
7. **数据库 v2**：`messages` 表新增 `completionTokens`，用于气泡下方的「输入 / 输出 / 缓存」消耗展示；v1 → v2 有 `MIGRATION_1_2`，升级不丢历史会话。
8. **官方接口对齐（2026 文档）**：模型只有 `deepseek-flash` / `deepseek-v4-pro`，`deepseek-chat` / `deepseek-reasoner` 已下线；「测试连接」先 `GET /models` 校验可用模型，发现当前模型不可用会自动切换并保存。设置迁移（v4）也会把旧模型名纠正为 `deepseek-flash`。
9. **联网搜索**（官方服务端工具）：输入框上方快捷开关声明 `deepseek_web_search`，搜索在服务端完成、客户端不执行工具；与 function 工具互斥、不能设 `tool_choice`、仅 `deepseek-flash`；搜索进度通过 `server_tool_event` 显示，来源从 `annotations` / `server_tool_calls[].sources` 提取。
