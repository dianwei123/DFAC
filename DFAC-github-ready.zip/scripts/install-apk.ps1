# 安装 debug APK 到已连接的 Android 设备
# 用法：powershell -ExecutionPolicy Bypass -File scripts/install-apk.ps1 [-Apk <path>]
param(
    [string]$Apk
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot

if (-not $Apk) {
    $Apk = Join-Path $root 'dist\DFAC-1.2.0-debug.apk'
}
if (-not (Test-Path $Apk)) {
    $fallback = Join-Path $root 'app\build\outputs\apk\debug\app-debug.apk'
    if (Test-Path $fallback) { $Apk = $fallback } else { Write-Error "找不到 APK：$Apk" }
}

$adb = $null
if ($env:ANDROID_HOME) { $adb = Join-Path $env:ANDROID_HOME 'platform-tools\adb.exe' }
if (-not $adb -or -not (Test-Path $adb)) {
    $cmd = Get-Command adb -ErrorAction SilentlyContinue
    if ($cmd) { $adb = $cmd.Source }
}
if (-not $adb) { Write-Error "找不到 adb，请安装 platform-tools 并加入 PATH。" }

& $adb devices
& $adb install -r $Apk
Write-Host "安装完成。启动命令：adb shell monkey -p com.memorychat.debug -c android.intent.category.LAUNCHER 1"
