# 构建 debug APK
# 用法：powershell -ExecutionPolicy Bypass -File scripts/build-apk.ps1 [-JdkHome C:\path\to\jdk17]
param(
    [string]$JdkHome = $env:JAVA_HOME
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot

if (-not $JdkHome -or -not (Test-Path $JdkHome)) {
    Write-Error "未找到 JDK 17。请先安装 JDK 17，或用 -JdkHome 指定路径（例如 C:\Program Files\Eclipse Adoptium\jdk-17*）。"
}
$env:JAVA_HOME = $JdkHome

if (-not $env:ANDROID_HOME -and -not $env:ANDROID_SDK_ROOT) {
    $candidates = @(
        "$env:LOCALAPPDATA\Android\Sdk",
        "C:\Android\Sdk",
        "$env:USERPROFILE\AppData\Local\Android\Sdk"
    ) | Where-Object { Test-Path $_ }
    if ($candidates.Count -eq 0) {
        Write-Error "未找到 Android SDK。请先安装 Android Studio 或在 local.properties 里写 sdk.dir。"
    }
    $env:ANDROID_HOME = $candidates[0]
}

Push-Location $root
try {
    & .\gradlew.bat :app:assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "构建失败，退出码 $LASTEXITCODE" }
    $apk = Join-Path $root 'app\build\outputs\apk\debug\app-debug.apk'
    $dist = Join-Path $root 'dist'
    New-Item -ItemType Directory -Force -Path $dist | Out-Null
    Copy-Item $apk (Join-Path $dist 'DFAC-1.2.0-debug.apk') -Force
    Write-Host "APK 已生成：$dist\DFAC-1.2.0-debug.apk"
} finally {
    Pop-Location
}
