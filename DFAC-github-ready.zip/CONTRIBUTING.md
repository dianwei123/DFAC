# Contributing

感谢愿意改进 DFAC。仓库结构见 README「工程结构」一节。

## 本地开发

要求：JDK 17、Android SDK 35（`platforms;android-35`、`build-tools;35.0.0`）。

```bash
# Android Studio 直接 Open 本目录；命令行：
./gradlew :app:assembleDebug
./gradlew :app:testDebugUnitTest
```

`local.properties` 不要提交（已在 `.gitignore` 中），Android Studio 会按本机 SDK 自动生成。

## 改动约定

1. **先跑测试**：提交前执行 `./gradlew :app:testDebugUnitTest`，CI 也会跑。
2. **保持分层**：`domain/` 只放纯 Kotlin（可 JVM 单测），Android 依赖放 `data/`、`network/`、`work/`、`ui/`。
3. **接口对齐官方文档**：模型 ID、`thinking`、`reasoning_effort`、联网工具等以 <https://api-docs.deepseek.com/zh-cn/> 为准，改了就在 `README.md` 的对照表补一行。
4. **压缩链路相关改动必须补测试**：token 估算、前缀 hash、组装、缓存体检、限流重试这些都在 `app/src/test/` 有对应用例。
5. **不要提交**：`local.properties`、`build/`、`dist/`、APK、签名文件。

## 提交 PR

- 描述里写清楚：动机、改动点、如何验证（命令 / 截图）。
- 如果改动了 DeepSeek 协议层，请附上官方文档链接与对应的 MockWebServer 测试。
- 版本号变更请同步 `app/build.gradle.kts` 与 `CHANGELOG.md`。
