# Changelog

本项目遵循语义化版本（`versionCode` 递增）。APK 通过 GitHub Releases 分发。

## [1.2.0] - versionCode 3

### Added

- 右侧侧边栏改为两个页签：**历史对话**（默认）与 **设置**
- 历史对话列表：会话标题、更新时间、压缩统计、当前高亮；点按切换、长按删除、新建对话
- 会话级统计独立：每个会话有自己的 `compressedRounds` / `savedTokens` / 缓存命中率
- `GET /models` 结果持久化：测试连接后下拉框直接展示 Key 真实可用的模型
- 侧边栏设置页显示版本号（`BuildConfig.VERSION_NAME` / `VERSION_CODE`）

### Changed

- 侧边栏默认落在「历史对话」页；工具栏图标打开侧边栏
- README 重写，增加官方接口对齐表、界面说明与发布步骤
- 仓库整理为可直接上传 GitHub 的结构（LICENSE / CHANGELOG / CI / .gitattributes）

### Fixed

- README 曾有编码损坏，已整篇重建

## [1.1.0] - versionCode 2

### Added

- 对齐 DeepSeek 2026 官方文档：模型改为 `deepseek-flash` / `deepseek-v4-pro`
- 思考模式开关 + `reasoning_effort`（low / high / max），解析 `reasoning_content`
- 联网搜索开关（官方服务端工具 `deepseek_web_search`），解析 `server_tool_event` 与引用来源
- 输入框上方「联网搜索 / 深度思考」快捷开关
- 顶部 token 消耗组件（上下文 / 本轮 / 缓存 / 压缩节省）
- LLM 调用总开关（关闭后只落库、不发请求、不跑摘要 Worker）
- 「测试连接」自动用 `GET /models` 校正模型并提示可用列表
- 设置版本迁移（v2~v4）：抬高偏小的 `max_tokens` / 阈值，纠正已下线的模型名

### Changed

- 模型从手输改为下拉选择
- 设置整体移入右侧 DrawerLayout
- 人设提示词允许长回复；`max_tokens` 默认 2048 → 4096；压缩阈值 8000 → 16000
- 输入区用 `WindowInsets.ime()` 避让键盘

### Fixed

- **`NetworkOnMainThreadException`**：非流式 `complete()` 未切 IO 线程，导致「测试连接」必现失败
- `temperature` 显示 `1.299999952316` 的浮点尾巴
- 数据库升到 v2（`messages.completionTokens`），带 `MIGRATION_1_2`

## [1.0.0] - versionCode 1

### Added

- 按架构图落地首版：Room 消息表 → token 估算 → 超阈值压缩 → 前缀 hash → `summary_cache` 冻结 → 组装请求 → OkHttp SSE 流式 → usage / prompt cache 命中率体检 → UI 渲染
- WorkManager 异步摘要 + 超时 fail-open
- 指数退避重试（429/5xx，最多 3 次）、4xx 直接错误态并可重发
- 离线 Mock 模式（未填 API Key 时自动启用）
- 27 个 domain 单测 + Robolectric 运行时测试
